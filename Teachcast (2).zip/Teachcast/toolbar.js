// Global Items Here:
let toolbar;
let toolbarButtons;
let openEditBar;
let getXYPos;
let deleteAnnotation;
///////////////////

let subTools = {
  select: [
    ["Select Tool", "./images/toolbar/cursor.svg"],
    ["Hand Tool", "./images/toolbar/sub/drag.svg"]
  ],
  annotate: [
    ["Select Highlighter", "./images/toolbar/sub/texthighlighter.svg"],
    ["Box Highlighter", "./images/toolbar/sub/boxhighlighter.svg"],
    "LINEBREAK",
    ["Underline", "./images/toolbar/sub/underline.svg"],
    ["Strikethrough", "./images/toolbar/sub/strikethrough.svg"],
    "LINEBREAK",
    "COLOR"
  ],
  draw: [
    "COLOR",
    "THICKNESS",
    "TRANSPARENCY",
    ["Eraser", "./images/toolbar/sub/eraser.svg", { toggle: true, toggledImg: "./images/toolbar/draw.svg" }]
  ],
  shapes: [
    ["Square", "./images/toolbar/sub/square.svg"],
    ["Circle", "./images/toolbar/sub/circle.svg"],
    ["Triangle", "./images/toolbar/sub/triangle.svg"],
    ["Line", "./images/toolbar/sub/line.svg"]
  ],
  note: [
    ["Comment", "./images/toolbar/sub/note.svg"],
    ["Sticky Note", "./images/toolbar/sub/stickeynote.svg"]
  ],
  media: [
    ["Image", "./images/toolbar/media.svg"],
    ["Embed", "./images/toolbar/sub/embed.svg"]
  ]
};

mainLoadActions.toolbar = function actionInitToolbar() {
  toolbar = findC("toolbar");
  toolbarButtons = findC("toolbar-main").childNodes;
  
  let subToolDropdown = null;
  let subToolHolder = null;
  
  let wideHolder = null;
  let currentParentB = null;
  let currentWideUI = "";
  async function createWideHolder(parentB, contentHolder, dispUnder) {
    if (currentParentB != null) {
      let triangle = currentParentB.querySelector(".toolbar-dropdown-triangle");
      if (triangle != null) {
        async function removeTri() {
          triangle.style.width = "0px";
          await sleep(150);
          triangle.remove(triangle);
        }
        removeTri(triangle);
      }
    }
    currentParentB = parentB;
    if (wideHolder == null) {
      wideHolder = createElement("toolbar-wide", "div", stuckHolder);
    }
    if (wideHolder.querySelector(".wide-toolbar-holder") != null) {
      wideHolder.querySelector(".wide-toolbar-holder").remove();
    }
    wideHolder.appendChild(contentHolder);
    if (dispUnder != true) {
      let rect = parentB.getBoundingClientRect();
      wideHolder.style.left = rect.left + rect.width + 6 + "px";
      wideHolder.style.top = rect.top + "px";
      let buttonT = createElement("toolbar-dropdown-triangle", "div", parentB, { "transform": "translateY(-50%)" });
      await sleep(1);
      buttonT.style.width = "12px";
    } else {
      wideHolder.style.backdropFilter = "none";
      parentB.parentElement.appendChild(wideHolder);
      let rect = parentB.parentElement.getBoundingClientRect();
      wideHolder.style.left = (rect.width / 2) - (contentHolder.clientWidth / 2) - 4 + "px";
      wideHolder.style.bottom = rect.height + 4 + "px";
    }
    wideHolder.style.opacity = 1;
    wideHolder.style.width = contentHolder.clientWidth + "px";
  }
  let specialTooltips = {
    COLOR: function(parentB, subBData, dispUnder) {
      let sessionInsert = session.inserting;
      let subUiHolder = createElement("wide-toolbar-holder", "div", body);
      let colors = subBData.colors;
      let colorDispHolder = null;
      let customSelect = createElement("color-select-custom", "input", subUiHolder);
      customSelect.value = session.currentSetProp.color;
      customSelect.setAttribute("type", "color");
      customSelect.addEventListener("input", function() {
        colors[colors.indexOf(session.currentSetProp.color)] = customSelect.value;
        session.currentSetProp.color = customSelect.value;
        subBData.color = session.currentSetProp.color;
        updateColors();
        updateMiniDisplays();
      });
      customSelect.addEventListener("change", pushColorChangeLive);
      function updateColors() {
        if (colorDispHolder != null) {
          colorDispHolder.remove();
        }
        colorDispHolder = createElement("color-display-holder", "div", subUiHolder, { "display": "flex" });
        subUiHolder.insertBefore(colorDispHolder, customSelect);
        for (let i = 0; i < colors.length; i++) {
          let selectButton = createElement("color-select-circle", "div", colorDispHolder, { "background-color": colors[i] });
          if (colors[i] == session.currentSetProp.color) {
            selectButton.style.borderWidth = "3px";
          }
          selectButton.setAttribute("setColor", colors[i]);
          selectButton.addEventListener("click", function() {
            session.currentSetProp.color = this.getAttribute("setColor");
            subBData.color = session.currentSetProp.color;
            let parentNodes = this.parentElement.childNodes;
            for (let b = 0; b < parentNodes.length; b++) {
              if (parentNodes[b].className == "color-select-circle") {
                parentNodes[b].style.borderWidth = "0px";
              }
            }
            this.style.borderWidth = "3px";
            updateMiniDisplays();
            pushColorChangeLive();
          });
        }
      }
      updateColors();
      function updateMiniDisplays() {
        let colorSelectCircle = findC("toolbar-sub-color-selected");
        if (colorSelectCircle != null) {
          colorSelectCircle.style.backgroundColor = session.currentSetProp.color;
        }
        customSelect.value = session.currentSetProp.color;
        if (session.inserting != null) {
          session.inserting.c = session.currentSetProp.color;
          if (session.currentTool == "select") {
            renderItem(session.inserting);
          }
        }
      }
      function pushColorChangeLive() {
        sendMemberUpdate(false);
        /*
        if (sessionInsert != null && session.currentTool == "select") {
          saveChange(sessionInsert);
        }
        */
      }
      createWideHolder(parentB, subUiHolder, dispUnder);
    },
    THICKNESS: function(parentB, subBData, dispUnder) {
      let subUiHolder = createElement("wide-toolbar-holder", "div", body);
      let sliderValue = createElement("solid-select-slider", "input", subUiHolder);
      sliderValue.setAttribute("type", "range");
      sliderValue.setAttribute("min", "1");
      sliderValue.setAttribute("max", "12");
      sliderValue.value = session.currentSetProp.thickness || 2;
      sliderValue.addEventListener("input", updateValue);
      let customValue = createElement("solid-select-value", "input", subUiHolder, { "width": "38px" });
      customValue.setAttribute("type", "number");
      customValue.setAttribute("min", "1");
      customValue.setAttribute("max", "36");
      customValue.value = session.currentSetProp.thickness || 2;
      customValue.addEventListener("input", updateValue);
      function updateValue() {
        let value = parseInt(this.value);
        session.currentSetProp.thickness = value;
        subBData.thickness = value;
        sliderValue.value = value;
        customValue.value = value;
        let subButtonText = findI("toolbar-sub-button-text-thickness");
        if (subButtonText != null) {
          subButtonText.textContent = value + "px";
        }
        if (session.inserting != null) {
          session.inserting.t = session.currentSetProp.thickness;
          if (session.currentTool == "select") {
            renderItem(session.inserting);
          }
        }
      }
      createWideHolder(parentB, subUiHolder, dispUnder);
    },
    TRANSPARENCY: function(parentB, subBData, dispUnder) {
      let subUiHolder = createElement("wide-toolbar-holder", "div", body);
      let sliderValue = createElement("solid-select-slider", "input", subUiHolder);
      sliderValue.setAttribute("type", "range");
      sliderValue.setAttribute("min", "10");
      sliderValue.setAttribute("max", "100");
      sliderValue.setAttribute("step", "10");
      sliderValue.value = (session.currentSetProp.opacity || 1)*100;
      sliderValue.addEventListener("input", updateValue);
      let customValue = createElement("solid-select-value", "input", subUiHolder, { "width": "48px" });
      customValue.setAttribute("type", "number");
      customValue.setAttribute("min", "0");
      customValue.setAttribute("max", "100");
      customValue.value = (session.currentSetProp.opacity || 1)*100;
      customValue.addEventListener("input", updateValue);
      function updateValue() {
        let value = parseInt(this.value);
        session.currentSetProp.opacity = value / 100;
        subBData.opacity = session.currentSetProp.opacity;
        sliderValue.value = value;
        customValue.value = value;
        let subButtonText = findI("toolbar-sub-button-text-transparency");
        if (subButtonText != null) {
          subButtonText.textContent = value + "%";
        }
        let transImg = findC("toolbar-button-img-transparency");
        if (transImg != null) {
          transImg.style.opacity = session.currentSetProp.opacity;
        }
        if (session.inserting != null) {
          session.inserting.o = session.currentSetProp.opacity;
          if (session.currentTool == "select") {
            renderItem(session.inserting);
          }
        }
      }
      createWideHolder(parentB, subUiHolder, dispUnder);
    }
  };
  async function closeWideHolder() {
    if (wideHolder != null) {
      currentWideUI = "";
      wideHolder.style.opacity = 0;
      let triangle = currentParentB.querySelector(".toolbar-dropdown-triangle");
      if (triangle != null) {
        wideHolder.style.width = "0px";
        triangle.style.width = "0px";
      }
      await sleep(150);
      if (wideHolder != null) {
        wideHolder.remove();
      }
      if (triangle != null) {
        triangle.remove(triangle);
      }
      wideHolder = null;
    }
  }
  
  async function renderSubButtons(button) {
    let subButtons = subTools[button.id];
    let triangle = button.querySelector(".toolbar-dropdown-triangle");
    let lastSubProp = session.lastSubProp[button.id] || {};
    session.currentSetProp = lastSubProp;
    session.currentSubTool = "";
    if (subButtons != null && (session.currentTool != button.id || (session.currentTool == button.id && subToolDropdown == null))) {
      if (subToolDropdown == null) {
        subToolDropdown = createElement("toolbar-sub", "div", toolbar);
      }
      if (subToolHolder != null) {
        subToolHolder.remove();
      }
      subToolHolder = createElement("toolbar-sub-holder", "div", subToolDropdown);
      let lastSubButton = session.lastSubTool[button.id] || subButtons[0][0].toLowerCase();
      for (let i = 0; i < subButtons.length; i++) {
        let subBData = subButtons[i];
        let subToolButton = null;
        if (typeof subBData == "object") {
          function createSubButton() {
            let subBData = subButtons[i];
            subToolButton = createElement("toolbar-sub-button", "div", subToolHolder);
            subToolButton.id = subBData[0].toLowerCase();
            if (subBData[1] != null) {
              createElement("toolbar-button-img", "img", subToolButton).src = subBData[1];
            }
            if (lastSubButton == subBData[0].toLowerCase()) {
              session.currentSubTool = subToolButton.id;
              subToolButton.style.backgroundColor = themeColor;
            }
            let subButtonExtraProp = subBData[2] || {};
            if (subButtonExtraProp.toggle == true) {
              subToolButton.setAttribute("toggle", "");
              subToolButton.setAttribute("OriginalImg", subBData[1]);
            }
            subToolButton.addEventListener("click", async function() {
              if (session.currentSubTool == subToolButton.id) {
                if (subButtonExtraProp.toggle == true) {
                  session.currentSubTool = "";
                  if (session.currentTool != button.id) {
                    session.currentTool = button.id;
                    stopTool();
                    if (toolFunctions[button.id + "Init"] != null) {
                      toolFunctions[button.id + "Init"]();
                    }
                  }
                  if (subToolButton.querySelector(".toolbar-button-img") != null) {
                    subToolButton.querySelector(".toolbar-button-img").src = subToolButton.getAttribute("OriginalImg");
                  }
                }
                return;
              }
              session.currentSubTool = subToolButton.id;
              let parentButtons = subToolButton.parentElement.childNodes;
              for (let i = 0; i < parentButtons.length; i++) {
                let button = parentButtons[i];
                if (button.id != "" && button.hasAttribute("property") == false && button.id != session.currentSubTool) {
                  button.style.backgroundColor = "rgba(0, 0, 0, 0)";
                }
              }
              if (subButtonExtraProp.toggle != true) {
                session.lastSubTool[button.id] = subToolButton.id;
                if (session.currentTool != button.id) {
                  session.currentTool = button.id;
                  stopTool();
                  if (toolFunctions[button.id + "Init"] != null) {
                    toolFunctions[button.id + "Init"]();
                  }
                }
                subToolButton.style.backgroundColor = themeColor;
              } else {
                session.currentTool = subToolButton.id;
                closeWideHolder();
                if (toolFunctions[subToolButton.id + "SubInit"] != null) {
                  stopTool();
                  toolFunctions[subToolButton.id + "SubInit"]();
                  if (subButtonExtraProp.toggledImg != null && subToolButton.querySelector(".toolbar-button-img")) {
                    subToolButton.querySelector(".toolbar-button-img").src = subButtonExtraProp.toggledImg;
                  }
                }
                subToolButton.style.backgroundColor = "#505B77";
              }
            });
          }
          createSubButton();
        } else if (subBData == "COLOR") {
          subToolButton = createElement("toolbar-sub-button", "div", subToolHolder);
          subToolButton.id = "color-picker";
          subToolButton.setAttribute("property", "");
          createElement("toolbar-button-img", "img", subToolButton, { width: "36px", height: "36px" }).src = "./images/toolbar/sub/color.svg";
          if (lastSubProp.color != null) {
            session.currentSetProp.color = lastSubProp.color;
          }
          createElement("toolbar-sub-color-selected", "div", subToolButton, { "background-color": session.currentSetProp.color })  
        } else if (subBData == "THICKNESS") {
          subToolButton = createElement("toolbar-sub-button", "div", subToolHolder);
          subToolButton.id = "line-thickness";
          subToolButton.setAttribute("property", "");
          createElement("toolbar-button-img", "img", subToolButton, { width: "36px", height: "36px" }).src = "./images/toolbar/sub/linethick.svg";
          let subBText = createElement("toolbar-sub-button-text", "div", subToolButton);
          if (lastSubProp.thickness != null) {
            session.currentSetProp.thickness = lastSubProp.thickness;
          }
          subBText.textContent = (session.currentSetProp.thickness || 2) + "px";
          subBText.id = "toolbar-sub-button-text-thickness";
          //lastSubProp.color = subToolButton.style.backgroundColor;
          //session.currentSetProp.color = subToolButton.style.backgroundColor;
          //createElement("toolbar-dropdown-triangle", "div", subToolButton, { width: "12px", transform: "translateY(-50%) rotateY(180deg)" });
        } else if (subBData == "TRANSPARENCY") {
          subToolButton = createElement("toolbar-sub-button", "div", subToolHolder);
          subToolButton.id = "transparency";
          subToolButton.setAttribute("property", "");
          createElement("toolbar-button-img-transparency", "img", subToolButton, { width: "36px", height: "36px", opacity: session.currentSetProp.opacity, transition: "all .1s ease" }).src = "./images/toolbar/sub/opacity.svg";
          let subBText = createElement("toolbar-sub-button-text", "div", subToolButton);
          if (lastSubProp.opacity != null) {
            session.currentSetProp.opacity = lastSubProp.opacity;
          }
          subBText.textContent = (session.currentSetProp.opacity || 1)*100 + "%";
          subBText.id = "toolbar-sub-button-text-transparency";
          //lastSubProp.color = subToolButton.style.backgroundColor;
          //session.currentSetProp.color = subToolButton.style.backgroundColor;
          //createElement("toolbar-dropdown-triangle", "div", subToolButton, { width: "12px", transform: "translateY(-50%) rotateY(180deg)" });
        } else if (subBData == "LINEBREAK") {
          createElement("dropdown-line-break", "div", subToolHolder, { margin: "0px 0px 6px 0px" });
        }
        if (typeof subBData == "string" && specialTooltips[subBData] != null && subToolButton != null) {
          subToolButton.addEventListener("click", async function() {
            let parentButtons = subToolButton.parentElement.childNodes;
            for (let i = 0; i < parentButtons.length; i++) {
              let button = parentButtons[i];
              if (button.hasAttribute("toggle") == true) {
                if (button.querySelector(".toolbar-button-img") != null) {
                  button.querySelector(".toolbar-button-img").src = button.getAttribute("OriginalImg");
                }
              }
            }
            if (session.currentTool != button.id) {
              session.currentSubTool = "";
              session.currentTool = button.id;
              stopTool();
              if (toolFunctions[button.id + "Init"] != null) {
                toolFunctions[button.id + "Init"]();
              }
            }
            if (currentWideUI != subBData) {
              currentWideUI = subBData;
              specialTooltips[subBData](subToolButton, lastSubProp);
            } else {
              closeWideHolder();
            }
          });
        }
        if (subToolButton != null) {
          subToolButton.addEventListener("mouseenter", function() {
            if (session.currentSubTool != subToolButton.id.toLowerCase() || subToolButton.hasAttribute("toggle") == true) {
              subToolButton.style.backgroundColor = "#505B77";
            }
          });
          subToolButton.addEventListener("mouseleave", function() {
            if (session.currentSubTool != subToolButton.id.toLowerCase() || subToolButton.hasAttribute("toggle") == true) {
              subToolButton.style.backgroundColor = "rgba(0, 0, 0, 0)";
            }
          });
        }
      }
      subToolDropdown.style.height = subToolHolder.clientHeight - 6 + "px";
      subToolDropdown.style.top = button.getBoundingClientRect().top - toolbar.getBoundingClientRect().top + "px";
      if (triangle == null) {
        triangle = createElement("toolbar-dropdown-triangle", "div", button);
        await sleep(1);
        triangle.style.width = "12px";
      } else {
        triangle.style.transform = "translateY(-50%) rotateY(180deg)";
      }
    } else if (subToolDropdown != null) {
      if (triangle != null) {
        triangle.style.transform = "translateY(-50%)";
      }
      let removeSub = subToolDropdown;
      subToolDropdown = null;
      removeSub.style.top = button.getBoundingClientRect().top - toolbar.getBoundingClientRect().top + "px";
      removeSub.style.height = "0px";
      removeSub.style.opacity = 0;
      await sleep(150);
      removeSub.remove();
    }
  }
  function toolbarButtonClick(button) {
    closeWideHolder();
    renderSubButtons(button);
    if (session.currentTool == button.id) {
      return;
    }
    session.currentTool = button.id;
    stopTool();
    if (toolFunctions[button.id + "Init"] != null) {
      toolFunctions[button.id + "Init"]();
    }
    sendMemberUpdate(false);
    for (let i = 0; i < toolbarButtons.length; i++) {
      let button = toolbarButtons[i];
      if (button.id != null && button.id != session.currentTool) {
        button.style.backgroundColor = "rgba(0, 0, 0, 0)";
        let triangle = button.querySelector(".toolbar-dropdown-triangle");
        if (triangle != null) {
          async function removeTri() {
            triangle.style.width = "0px";
            await sleep(150);
            triangle.remove(triangle);
          }
          removeTri(triangle);
        }
      }
    }
    button.style.backgroundColor = themeColor;
    /*
    if (subButtons != null && subToolDropdown != null) {
      let triangle = createElement("toolbar-dropdown-triangle", "div", button);
      await sleep(1);
      triangle.style.width = "12px";
    }
    */
  }
  function handleToolbarButton(button) {
    button.addEventListener("click", async function() {
      toolbarButtonClick(button);
    });
    button.addEventListener("mouseenter", function() {
      if (button.style.backgroundColor == "rgba(0, 0, 0, 0)" || button.style.backgroundColor == "") {
        button.style.backgroundColor = "#505B77";
      }
    });
    button.addEventListener("mouseleave", function() {
      if (button.style.backgroundColor == "rgb(80, 91, 119)") {
        button.style.backgroundColor = "rgba(0, 0, 0, 0)";
      }
    });
  }
  
  for (let i = 0; i < toolbarButtons.length; i++) {
    let button = toolbarButtons[i];
    if (button.id != "") {
      handleToolbarButton(button);
    }
  }
  
  renderSubButtons(toolbarButtons[1]);
  
  // WHERE THE MAGIC HAPPENS
  
  let toolFunctions = {};
  let currentTool = "";
  let selectionBox = null;
  let editBar = null;
  
  function stopTool() {
    session.inserting = null;
    session.editing = false;
    currentTool = "";
    for (let i = 0; i < tempListeners.length; i++) {
      let remEvent = tempListeners[i];
      if (remEvent.subLis == true) {
        remEvent.parent.removeEventListener(remEvent.name, remEvent.listener);
      }
    }
    body.style.userSelect = "all";
    docHolder.style.touchAction = "auto";
    scrollingEnabled = true;
  
    let lockedPlacing = findI("locked-placing-element");
    if (lockedPlacing != null) {
      lockedPlacing.remove();
    }
    stopSelection();
  }
  
  function createListener(parent, listen, runFunc, key) {
    parent.addEventListener(listen, runFunc);
    tempListeners.push({ parent: parent, name: listen, listener: runFunc, key: key, subLis: true });
  }
  function removeListenerKey(key) {
    for (let i = 0; i < tempListeners.length; i++) {
      let remEvent = tempListeners[i];
      if (remEvent.key == key && remEvent.subLis == true) {
        remEvent.parent.removeEventListener(remEvent.name, remEvent.listener);
      }
    }
  }
  
  function setNewItem(data) {
    data.id = "anno_" + Date.now();
    session.annotations[data.id] = data;
    return data;
  }
  
  deleteAnnotation = function deleteAnnotation(annoID, stopAnyway) {
    if ((session.inserting != null && session.inserting.id == annoID) || stopAnyway == true) {
      stopSelection(true);
      session.inserting = null;
      sendAnnotationUpdate(annoID);
      saveChange(annoID);
    }
    if (session.annotations[annoID] != null) {
      delete session.annotations[annoID];
    }
    let renderedItem = findI("annotation_" + annoID);
    if (renderedItem != null) {
      renderedItem.remove();
    }
  }
  tempListen(document, "keydown", function(e) {
    if (e.key == "Backspace") {
      if (session.inserting != null && session.inserting.local != null && session.inserting.local.elem != null && session.inserting.local.elem.id != "locked-placing-element") {
        deleteAnnotation(session.inserting.id);
      }
    } else if (e.ctrlKey == true) {
      if (e.key == "z") {
        
      } else if (e.key == "d") {
        if (session.inserting != null && selectionBox != null) {
          let newAnno = { ...session.inserting };
          if (newAnno.local != null) {
            delete newAnno.local;
          }
          session.inserting = setNewItem(newAnno);
          if (session.inserting.x != null) {
            session.inserting.x += 20;
          }
          if (session.inserting.y != null) {
            session.inserting.y += 20;
          }
          renderItem(session.inserting);
          openSelectBox(session.inserting.id, e);
          sendMemberUpdate(false);
          saveChange(session.inserting);
        }
        e.preventDefault();
        e.stopPropagation();
      }
    }
  });
  
  let funcToStore = {
    shape: "shapes"
  };
  let lastFunc = "";
  openEditBar = async function openEditBar(props, ignoreInvis) {
    if (selectionBox == null) {
      return;
    }
    if (editBar != null) {
      if (session.currentTool != "select") {
        hideEditBar();
        return;
      }
      if (ignoreInvis == true) {
        async function removeOldBar() {
          let remEditBar = editBar;
          remEditBar.style.opacity = 0;
          await sleep(300);
          remEditBar.remove();
        }
        removeOldBar();
        editBar = null;
      }
    }
    if (editBar == null) {
      lastFunc = "";
      editBar = createElement("selection-box-edit-bar", "div", annotationsHolder);
      await sleep(1);
    }
    if (lastFunc != session.inserting.f) {
      lastFunc = session.inserting.f;
      let lastSubProp = session.lastSubProp[funcToStore[session.inserting.f] || session.inserting.f];
      if (lastSubProp == null) {
        session.lastSubProp[funcToStore[session.inserting.f || session.inserting.f]] = {};
        lastSubProp = {};
      }
      lastSubProp.lastSelectedShape = session.inserting;
      lastSubProp.color = session.inserting.c || lastSubProp.color || "#000";
      lastSubProp.thickness = session.inserting.t || lastSubProp.thickness || 0;
      lastSubProp.opacity = session.inserting.o || lastSubProp.opacity || 0;
      session.currentSetProp = lastSubProp;
      let currentlyOpen = "";
      let globalFunc = {
        "color": function() {
          let colorB = createElement("selection-box-edit-bar-tile", "div", editBar);
          createElement("toolbar-sub-color-selected", "div", colorB, { "background-color": lastSubProp.color }).id = "selection-box-edit-bar-color-selected";
          colorB.setAttribute("onmouseenter", 'this.style.backgroundColor = "rgb(80, 91, 119)"'); 
          colorB.setAttribute("onmouseleave", 'this.style.backgroundColor = "rgba(0, 0, 0, 0)"');
          colorB.addEventListener("click", function() {
            if (wideHolder != null && currentlyOpen == "color") {
              currentlyOpen = "";
              closeWideHolder();
              return;
            }
            currentlyOpen = "color";
            specialTooltips["COLOR"](colorB, lastSubProp, true);
          });
        },
        "thickness": function() {
          let thickB = createElement("selection-box-edit-bar-tile", "div", editBar);
          createElement("selection-box-edit-img", "img", thickB).src = "./images/toolbar/sub/linethick.svg";
          thickB.setAttribute("onmouseenter", 'this.style.backgroundColor = "rgb(80, 91, 119)"'); 
          thickB.setAttribute("onmouseleave", 'this.style.backgroundColor = "rgba(0, 0, 0, 0)"');
          thickB.addEventListener("click", function() {
            if (wideHolder != null && currentlyOpen == "thickness") {
              currentlyOpen = "";
              closeWideHolder();
              return;
            }
            currentlyOpen = "thickness";
            specialTooltips["THICKNESS"](thickB, lastSubProp, true);
          });
        },
        "transparency": function() {
          let transB = createElement("selection-box-edit-bar-tile", "div", editBar);
          createElement("selection-box-edit-img", "img", transB).src = "./images/toolbar/sub/opacity.svg";
          transB.setAttribute("onmouseenter", 'this.style.backgroundColor = "rgb(80, 91, 119)"'); 
          transB.setAttribute("onmouseleave", 'this.style.backgroundColor = "rgba(0, 0, 0, 0)"');
          transB.addEventListener("click", function() {
            if (wideHolder != null && currentlyOpen == "transparency") {
              currentlyOpen = "";
              closeWideHolder();
              return;
            }
            currentlyOpen = "transparency";
            specialTooltips["TRANSPARENCY"](transB, lastSubProp, true);
          });
        },
        "subButtonHolder": function(buttonFunc) {
          let lineB = createElement("selection-box-edit-bar-tile", "div", editBar);
          createElement("selection-box-edit-img", "img", lineB).src = "./images/icons/editbar/linetype.svg";
          lineB.setAttribute("onmouseenter", 'this.style.backgroundColor = "rgb(80, 91, 119)"'); 
          lineB.setAttribute("onmouseleave", 'this.style.backgroundColor = "rgba(0, 0, 0, 0)"');
          lineB.addEventListener("click", function() {
            let buttonOp = buttonFunc();
            if (wideHolder != null && currentlyOpen == "linetype") {
              currentlyOpen = "";
              closeWideHolder();
              return;
            }
            currentlyOpen = "linetype";
            let subUiHolder = createElement("wide-toolbar-holder", "div", body, { "padding": "0px 3px 0px 3px" });
            for (let i = 0; i < buttonOp.length; i++) {
              if (buttonOp[i] == "divide-line") {
                createElement("selection-box-vertical-line-seperator", "div", subUiHolder);
              } else {
                let selB = createElement("selection-box-edit-bar-tile", "div", subUiHolder, { "width": "38px", "height": "38px", "margin": "6px 3px 6px 3px" });
                selB.id = "sub-select" + buttonOp[i][0];
                if (buttonOp[i][1] == true) {
                  selB.style.backgroundColor = themeColor;
                }
                createElement("selection-box-edit-img", "img", selB).src = buttonOp[i][2];
                selB.addEventListener("click", buttonOp[i][3]);
              }
            }
            createWideHolder(lineB, subUiHolder, true);
          });
        },
        "delete": function() {
          createElement("selection-box-vertical-line-seperator", "div", editBar);
          let trashB = createElement("selection-box-edit-bar-tile", "div", editBar);
          createElement("selection-box-edit-img", "img", trashB).src = "./images/icons/editbar/trashbin.svg";
          trashB.setAttribute("onmouseenter", 'this.style.backgroundColor = "rgb(80, 91, 119)"'); 
          trashB.setAttribute("onmouseleave", 'this.style.backgroundColor = "rgba(0, 0, 0, 0)"');
          trashB.addEventListener("click", function() {
            deleteAnnotation(session.inserting.id);
          });
        }
      };
      function setSubButtonStyle(butId, value) {
        let buttonObj = findI("sub-select" + butId);
        if (buttonObj != null) {
          buttonObj.style.backgroundColor = value;
        }
      }
      switch (session.inserting.f) {
        case "annotate":
          globalFunc["color"]();
          globalFunc["transparency"]();
          globalFunc["delete"]();
          break;
        case "text":
          globalFunc["color"]();
          globalFunc["delete"]();
          break;
        case "draw":
          globalFunc["color"]();
          globalFunc["thickness"]();
          globalFunc["transparency"]();
          function getLineTypes() {
            return [
              ["Solid", session.inserting.bo == null, "./images/icons/editbar/solidline.svg", function() {
                if (session.inserting.bo != null) {
                  delete session.inserting.bo;
                }
                setSubButtonStyle("Solid", themeColor);
                setSubButtonStyle("Dashed", "rgba(0, 0, 0, 0)");
                renderItem(session.inserting);
              }],
              ["Dashed", session.inserting.bo == "dash", "./images/icons/editbar/linetype.svg", function() {
                session.inserting.bo = "dash";
                setSubButtonStyle("Dashed", themeColor);
                setSubButtonStyle("Solid", "rgba(0, 0, 0, 0)");
                renderItem(session.inserting);
              }]
            ];
          }
          globalFunc["subButtonHolder"](getLineTypes);
          globalFunc["delete"]();
          break;
        case "shape":
          globalFunc["color"]();
          globalFunc["thickness"]();
          globalFunc["transparency"]();
          function getBorderTypes() {
            let mainSubFunc = [
              ["Solid Border", session.inserting.bo == null, "./images/icons/editbar/solidline.svg", function() {
                if (session.inserting.bo != null) {
                  delete session.inserting.bo;
                }
                setSubButtonStyle("Solid Border", themeColor);
                setSubButtonStyle("No Border", "rgba(0, 0, 0, 0)");
                setSubButtonStyle("Dashed Border", "rgba(0, 0, 0, 0)");
                renderItem(session.inserting);
              }],
              ["Dashed Border", session.inserting.bo == "dash", "./images/icons/editbar/linetype.svg", function() {
                session.inserting.bo = "dash";
                setSubButtonStyle("Dashed Border", themeColor);
                setSubButtonStyle("No Border", "rgba(0, 0, 0, 0)");
                setSubButtonStyle("Solid Border", "rgba(0, 0, 0, 0)");
                renderItem(session.inserting);
              }]
            ];
            if (session.inserting.s != "line") {
              mainSubFunc.unshift(["No Border", session.inserting.bo == "none", "./images/icons/editbar/noline.svg", function() {
                session.inserting.bo = "none";
                session.inserting.fi = true;
                setSubButtonStyle("No Border", themeColor);
                setSubButtonStyle("Solid Border", "rgba(0, 0, 0, 0)");
                setSubButtonStyle("Dashed Border", "rgba(0, 0, 0, 0)");
                setSubButtonStyle("Filled Shape", themeColor);
                renderItem(session.inserting);
              }]);
              mainSubFunc.push("divide-line");
              mainSubFunc.push(["Filled Shape", session.inserting.fi == true, "./images/icons/editbar/paintbucket.svg", function() {
                if (session.inserting.fi == null) {
                  session.inserting.fi = true;
                  setSubButtonStyle("Filled Shape", themeColor);
                } else {
                  if (session.inserting.bo == "none") {
                    return;
                  }
                  delete session.inserting.fi;
                  setSubButtonStyle("Filled Shape", "rgba(0, 0, 0, 0)");
                }
                renderItem(session.inserting);
              }]);
            }
            return mainSubFunc;
          }
          globalFunc["subButtonHolder"](getBorderTypes);
          globalFunc["delete"]();
          break;
      }
      if (session.inserting.id != null) {
        sendAnnotationUpdate(session.inserting);
      }
    }
    if (session.editing != true || ignoreInvis == true) {
      editBar.style.opacity = 1;
      editBar.style.pointerEvents = "all";
    } else {
      hideEditBar();
    }
    editBar.style.left = props.xPos + (props.setWidth / 2) - (editBar.clientWidth / 2) + 4 + "px";
    editBar.style.top = props.yPos - editBar.clientHeight - 10 + "px";
    if (editBar.getBoundingClientRect().y < 112) {
      editBar.style.top = props.yPos + props.setHeight + 18 + "px";
    }
  }
  
  getXYPos = function getXYPos(annoData, borderW) {
    let elem = annoData.local.elem;
    let props = elem.getBoundingClientRect();
    //let { x, y } = scaleToDoc(props.x, props.y);
    /*
    if (elem.nodeName == "g") {
      props = elem.getBBox();
    } else {
      props = elem.getBoundingClientRect();
    }
    */
    let setWidth = props.width;
    let setHeight = props.height;
    let xPos = annoData.x - (borderW || 4);
    let yPos = annoData.y - (borderW || 4);
    if (annoData.t != null && annoData.bo != "none") {
      setWidth += annoData.t;
      setHeight += annoData.t;
      xPos -= annoData.t / 2;
      yPos -= annoData.t / 2;
    }
    if (annoData.w <= 0) {
      xPos += annoData.w;
    }
    if (annoData.h <= 0) {
      yPos += annoData.h;
    }
    return { xPos: xPos, yPos: yPos, setWidth: setWidth, setHeight: setHeight };
  }
  function updateSelectBox(annoData, remPos) {
    remPos = remPos || 0;
    let posParams = getXYPos(annoData);
    selectionBox.style.width = posParams.setWidth + "px";
    selectionBox.style.height = posParams.setHeight + "px";
    selectionBox.style.left = posParams.xPos - remPos + "px";
    selectionBox.style.top = posParams.yPos - remPos + "px";
  }
  
  let scrollingEnabled = true;
  tempListen(body, "touchmove", function(e) {
    if (scrollingEnabled == false) {
      e.preventDefault();
    }
  }, { passive: false});
  
  let oppResizeTypes = {
    topleft: ["topright", "bottomleft"],
    topright: ["topleft", "bottomright"],
    bottomleft: ["bottomright", "topleft"],
    bottomright: ["bottomleft", "topright"],
  };
  let lastSelect = null;
  async function openSelectBox(annoID, e) {
    let annoData = session.annotations[annoID];
    if (annoData == null) {
      return;
    }
    let elem = annoData.local.elem;
    if (elem == null) {
      return;
    }
    if (session.currentTool != "select" && session.currentTool != "text") {
      toolbarButtonClick(findI("select"));
    }
    lastSelect = annoData;
    if (selectionBox != null) {
      selectionBox.remove();
      selectionBox = null;
    }
    selectionBox = createElement("selection-box", "div", annotationsHolder);
    selectionBox.setAttribute("annoID", annoData.id);
    createElement("selection-box-corner", "div", selectionBox, { "right": "-10px", "bottom": "-10px", "cursor": "se-resize" }).setAttribute("type", "bottomright");
    //if (annoData.s != "line") {
      createElement("selection-box-corner", "div", selectionBox, { "left": "-10px", "top": "-10px", "cursor": "se-resize" }).setAttribute("type", "topleft");
      createElement("selection-box-corner", "div", selectionBox, { "left": "-10px", "bottom": "-10px", "cursor": "sw-resize" }).setAttribute("type", "bottomleft");
      createElement("selection-box-corner", "div", selectionBox, { "right": "-10px", "top": "-10px", "cursor": "sw-resize" }).setAttribute("type", "topright");
    /*
    } else {
      createElement("selection-box-corner", "div", selectionBox, { "left": "-2px", "top": "-2px", "cursor": "se-resize" }).setAttribute("type", "topleft");
      selectionBox.style.borderStyle = "none";
    }
    */
    session.inserting = annoData;
    updateSelectBox(annoData, null);
    openEditBar(getXYPos(annoData), true);
    
    let currentAction = "";
    let resizeInfo = {};
    async function mouseDown(e) {
      session.editing = true;
      body.style.userSelect = "none";
      docHolder.style.touchAction = "pinch-zoom";
      scrollingEnabled = false;
      annoData = session.annotations[annoID];
      closeWideHolder();
      let { x, y } = scaleToDoc(e.clientX || e.changedTouches[0].clientX, e.clientY || e.changedTouches[0].clientY);
      let target = e.target || e.changedTouches[0].target;
      if (target.className == "selection-box-corner") {
        // Resize Object:
        currentAction = "resize";
        let setAction = target.getAttribute("type");
        if (annoData.w <= 0) {
          setAction = oppResizeTypes[setAction][0];
        }
        if (annoData.h <= 0) {
          setAction = oppResizeTypes[setAction][1];
        }
        resizeInfo.resize = setAction;
        resizeInfo.x = x;
        resizeInfo.y = y;
      } else {
        // Move Object:
        currentAction = "move";
        let { xPos: xPos, yPos: yPos } = getXYPos(annoData);
        annoData.local = annoData.local || {};
        annoData.local.x = xPos - x;
        annoData.local.y = yPos - y;
      }
      session.inserting = annoData;
      sendMemberUpdate(false);
      setSaveStatus("saving");
    }
    selectionBox.addEventListener("mousedown", mouseDown);
    selectionBox.addEventListener("touchstart", mouseDown);
    mouseDown(e);
    removeListenerKey("selection");
    function mouseMove(e) {
      annoData = session.annotations[annoID];
      if (annoData.local == null) {
        return;
      }
      let { x, y } = scaleToDoc(e.clientX || e.changedTouches[0].clientX, e.clientY || e.changedTouches[0].clientY);
      switch (currentAction) {
        case "move":
          if (annoData.x != null && annoData.y != null) {
            annoData.x = x + annoData.local.x + 4 + ((annoData.t || 0)/2);
            annoData.y = y + annoData.local.y + 4 + ((annoData.t || 0)/2);
            if (annoData.w <= 0) {
              annoData.x -= annoData.w;
            }
            if (annoData.h <= 0) {
              annoData.y -= annoData.h;
            }
          }
          //updateSelectBox(annoData);
          break;
        case "resize":
          let changeX = x - resizeInfo.x;
          let changeY = y - resizeInfo.y;
          if (e.shiftKey == true) {
            changeY = changeX;
          }
          resizeInfo.x = x;
          resizeInfo.y = y;
          if ((annoData.w == null || annoData.h == null) && annoData.local.elem != null) {
            let bBox = {};
            if (annoData.local.elem.getBBox != null) {
              bBox = annoData.local.elem.getBBox();
            } else {
              bBox = annoData.local.elem.getBoundingClientRect();
            }
            annoData.w = bBox.width;
            annoData.h = bBox.height;
          }
          switch (resizeInfo.resize) {
            case "topleft":
              annoData.w -= changeX;
              annoData.h -= changeY;
              annoData.x += changeX;
              annoData.y += changeY;
              break;
            case "topright":
              annoData.w += changeX;
              annoData.h -= changeY;
              annoData.y += changeY;
              break;
            case "bottomleft":
              annoData.w -= changeX;
              annoData.h += changeY;
              annoData.x += changeX;
              break;
            case "bottomright":
              annoData.w += changeX;
              annoData.h += changeY;
          }
      }
      renderItem(annoData);
    }
    createListener(docHolder, "mousemove", mouseMove, "selection");
    createListener(docHolder, "touchmove", mouseMove, "selection");
    function mouseUp(e) {
      body.style.userSelect = "all";
      docHolder.style.touchAction = "auto";
      scrollingEnabled = true;
      session.editing = false;
      currentAction = "";
      if (session.inserting != null) {
        if (annoData.id == session.inserting.id) {
          openEditBar(getXYPos(annoData));
        }
        if ((e.target || e.changedTouches[0].target).closest(".selection-box-edit-bar") == null) {
          saveChange(session.inserting);
        }
      }
    }
    createListener(body, "mouseup", mouseUp, "selection");
    createListener(body, "touchend", mouseUp, "selection");
  }
  
  async function hideEditBar() {
    if (editBar != null) {
      editBar.style.opacity = 0;
      editBar.style.pointerEvents = "none";
      closeWideHolder();
    }
  }
  
  function stopSelection(wasDelete) {
    if (session.inserting != null && wasDelete != true) {
      saveChange(session.inserting);
    }
    session.inserting = null;
    if (selectionBox != null) {
      selectionBox.remove();
      selectionBox = null;
    }
    hideEditBar();
    body.style.userSelect = "all";
    docHolder.style.touchAction = "auto";
    scrollingEnabled = true;
    removeListenerKey("selection");
    if (lastSelect != null && lastSelect.om != null) {
      delete lastSelect.om;
    }
    sendMemberUpdate(false);
    session.editing = false;
  }
  
  toolFunctions.selectInit = function(initAnno, initE) {
    function mouseDown(e) {
      //let clickElem = anno || document.elementFromPoint(e.clientX || e.changedTouches[0].clientX, e.clientY || e.changedTouches[0].clientY);
      let clickElem = e.target || e.changedTouches[0].target;
      if (clickElem != null && clickElem.getAttribute("class") == "annotation") {
        let annoID = clickElem.parentElement.getAttribute("id").replace(/annotation_/g, "");
        openSelectBox(annoID, e);
      } else if (clickElem.closest(".selection-box") == null && clickElem.closest(".selection-box-edit-bar") == null) {
        if (session.currentTool == "text") {
          let { x, y } = scaleToDoc(e.clientX || e.changedTouches[0].clientX, e.clientY || e.changedTouches[0].clientY);
          let newTextBox = setNewItem({
            f: "text",
            c: session.currentSetProp.color,
            x: x,// - (session.inserting.w/2),
            y: y// - (session.inserting.w/2)
          });
          renderItem(newTextBox);
          saveChange(newTextBox);
          openSelectBox(newTextBox.id, e);
        } else {
          stopSelection();
        }
      }
    }
    createListener(docHolder, "mousedown", mouseDown);
    createListener(docHolder, "touchstart", mouseDown);
    if (initAnno != null) {
      openSelectBox(initAnno, initE);
    }
  }
  toolFunctions.selectInit();
  
  toolFunctions.drawInit = function() {
    body.style.userSelect = "none";
    docHolder.style.touchAction = "pinch-zoom";
    docHolder.style.cursor = "url('./images/cursors/draw.png'), auto";
    let minX = null;
    let minY = null;
    function mouseDown(e, noUpdate) {
      let { x, y } = scaleToDoc(e.clientX || e.changedTouches[0].clientX, e.clientY || e.changedTouches[0].clientY);
      minX = x;
      minY = y;
      session.inserting = setNewItem({
        f: "draw",
        p: [x, y],
        c: session.currentSetProp.color,
        t: session.currentSetProp.thickness || 2,
        o: session.currentSetProp.opacity || 1
      });
      if (noUpdate != true) {
        sendMemberUpdate(false);
      }
      renderItem(session.inserting);
      setSaveStatus("saving");
    }
    createListener(docHolder, "mousedown", mouseDown);
    createListener(docHolder, "touchstart", mouseDown);
    function mouseMove(e) {
      if (session.inserting != null) {
        let { x, y } = scaleToDoc(e.clientX || e.changedTouches[0].clientX, e.clientY || e.changedTouches[0].clientY);
        if (x < minX || minX == null) {
          minX = x;
        }
        if (y < minY || minY == null) {
          minY = y;
        }
        session.inserting.p.push(x, y);
        renderItem(session.inserting);
        if (session.inserting.p.length > 6150) {
          mouseUp();
          mouseDown(e, true);
        }
      }
    }
    createListener(document, "mousemove", mouseMove);
    createListener(document, "touchmove", mouseMove);
    function mouseUp() {
      if (session.inserting == null) {
        return;
      }
      let annotation = session.annotations[session.inserting.id];
      annotation.x = minX || 0;
      annotation.y = minY || 0;
      for (let i = 0; i < annotation.p.length; i += 2) {
        annotation.p[i] = annotation.p[i] - annotation.x;
        annotation.p[i+1] = annotation.p[i+1] - annotation.y;
      }
      //sendAnnotationUpdate(annotation);
      saveChange(annotation);
      session.inserting = null;
    }
    createListener(document, "mouseup", mouseUp);
    createListener(document, "touchend", mouseUp);
  }
  
  toolFunctions.eraserSubInit = function() {
    body.style.userSelect = "none";
    docHolder.style.touchAction = "pinch-zoom";
    docHolder.style.cursor = "url('./images/cursors/draw.png'), auto";
    let eraseActive = false;
    function mouseDown(e) {
      session.inserting = { f: "erase" };
      eraseActive = true;
      sendMemberUpdate(false);
      mouseMove(e);
    }
    createListener(docHolder, "mousedown", mouseDown);
    createListener(docHolder, "touchstart", mouseDown);
    function mouseMove(e) {
      if (eraseActive == true) {
        let eraseElem = e.target || e.changedTouches[0].target;
        if (eraseElem != null) {
          if (eraseElem.getAttribute("class") == "annotation" && eraseElem.parentElement.getAttribute("id") != null) {
            let eraseId = eraseElem.parentElement.getAttribute("id").replace(/annotation_/g, "");
            if (session.annotations[eraseId] != null && session.annotations[eraseId].f == "draw") {
              deleteAnnotation(eraseId, true);
              if (session.inserting != null) {
                session.inserting.r = eraseId;
              }
              return;
            }
          }
          if (session.inserting != null && session.inserting.r != null) {
            delete session.inserting["r"];
          }
        }
      }
    }
    createListener(document, "mousemove", mouseMove);
    createListener(document, "touchmove", mouseMove);
    function mouseUp() {
      session.inserting = null;
      eraseActive = false;
    }
    createListener(document, "mouseup", mouseUp);
    createListener(document, "touchend", mouseUp);
  }
  
  toolFunctions.annotateInit = function() {
    let annoSelecting = false;
    function mouseDown() {
      annoSelecting = true;
    }
    createListener(docHolder, "mousedown", mouseDown);
    createListener(docHolder, "touchstart", mouseDown);
    function mouseUp(e) {
      if (annoSelecting == true) {
        annoSelecting = false;
        let { x, y } = scaleToDoc(e.clientX || e.changedTouches[0].clientX, e.clientY || e.changedTouches[0].clientY);
        let addTextSelect = [];
        let minX = null;
        let minY = null;
        if (window.getSelection != null) {
          let select = window.getSelection();
          if (select.rangeCount > 0) {
            let range = select.getRangeAt(0);
            if (range.toString().length > 0 && range.endContainer.parentNode.getAttribute("role") == "presentation") {
              let selections = range.getClientRects();
              let addedPrev = [];
              for (let i = 0; i < selections.length; i++) {
                let selRect = selections[i];
                let selRectScale = scaleToDoc(selRect.x, selRect.y);
                let selData = { w: Math.floor(selRect.width), h: Math.floor(selRect.height), x: selRectScale.x, y: selRectScale.y };
                if (selData.w > 0 && addedPrev.includes(selData.w + selData.x) == false) {
                  if (selRectScale.x < minX || minX == null) {
                    minX = selRectScale.x;
                  }
                  if (selRectScale.y < minY || minY == null) {
                    minY = selRectScale.y;
                  }
                  switch (session.currentSubTool) {
                    case "underline":
                      selData.y += selData.h;
                      selData.h = 4;
                      break;
                    case "strikethrough":
                      selData.y += selData.h / 2;
                      selData.h = 4;
                  }
                  addedPrev.push(selData.w + selData.x);
                  addTextSelect.push(selData);
                }
              }
            }
          }
        }
        if (addTextSelect.length < 1) {
          return;
        }
        if (window.getSelection) {window.getSelection().removeAllRanges();} else if (document.selection) {document.selection.empty();}
        session.mouse.selections = [];
        let setOpacity = 1;
        if (session.currentSubTool != null && session.currentSubTool.includes("highlighter") == true) {
          setOpacity = 0.5;
        }
        for (let i = 0; i < addTextSelect.length; i++) {
          addTextSelect[i].x = addTextSelect[i].x - (minX || 0);
          addTextSelect[i].y = addTextSelect[i].y - (minY || 0);
        }
        let newAnnotate = setNewItem({
          f: "annotate",
          p: addTextSelect,
          d: session.currentSubTool,
          c: session.currentSetProp.color,
          o: setOpacity,
          x: (minX || 0)*session.zoom,
          y: (minY || 0)*session.zoom
        });
        //sendAnnotationUpdate(newAnnotate);
        saveChange(newAnnotate);
        renderItem(newAnnotate);
        //openSelectBox(newAnnotate, e);
      }
    }
    createListener(document, "mouseup", mouseUp);
    createListener(document, "touchend", mouseUp);
  }

  toolFunctions.textInit = function() {
    toolFunctions.selectInit();
    /*
    function mouseDown(e) {
      if ((e.target).closest(".annotation") != null) {
        return;
      }
      toolFunctions.selectInit(null, null, true);
      let { x, y } = scaleToDoc(e.clientX || e.changedTouches[0].clientX, e.clientY || e.changedTouches[0].clientY);
      let newTextBox = setNewItem({
        f: "text",
        c: session.currentSetProp.color,
        x: x,// - (session.inserting.w/2),
        y: y// - (session.inserting.w/2)
      });
      renderItem(newTextBox);
      saveChange(newTextBox);
      toolFunctions.selectInit(newTextBox.id, e, null);
    }
    createListener(docHolder, "mousedown", mouseDown);
    createListener(docHolder, "touchstart", mouseDown);
    */
  }
  
  let toolShapeSVG = {
    "square": "rect",
    "circle": "ellipse",
    "triangle": "polygon"
  }
  toolFunctions.shapesInit = function() {
    body.style.userSelect = "none";
    session.inserting = {
      f: "shape",
      s: session.currentSubTool,
      c: session.currentSetProp.color,
      //fc: "",
      t: session.currentSetProp.thickness || 6
    };
    if (session.currentSetProp.lastSelectedShape != null) {
      session.inserting = { ...session.currentSetProp.lastSelectedShape };
    }
    session.inserting.w = 100;
    session.inserting.h = 100;
    session.inserting.p = true;
    if (session.inserting.id != null) {
      delete session.inserting.id;
    }
    if (session.inserting.local != null) {
      delete session.inserting.local;
    }
    sendMemberUpdate(false);
    function mouseMove(e) {
      if (session.inserting != null) {
        let { x, y } = scaleToDoc(e.clientX || e.changedTouches[0].clientX, e.clientY || e.changedTouches[0].clientY);
        session.inserting.s = toolShapeSVG[session.currentSubTool] || session.currentSubTool;
        if (session.inserting.s == "line" && session.inserting.bo == "none") {
          delete session.inserting.bo;
        }
        renderItem(session.inserting, { x: x - (session.inserting.w/2), y: y - (session.inserting.h/2), elem: findI("locked-placing-element") });
      }
    }
    createListener(document, "mousemove", mouseMove);
    createListener(document, "touchmove", mouseMove);
    function mouseDown(e) {
      let { x, y } = scaleToDoc(e.clientX || e.changedTouches[0].clientX, e.clientY || e.changedTouches[0].clientY);
      delete session.inserting.local;
      delete session.inserting.p;
      let renderAnno = setNewItem({ ...session.inserting, ...{
        s: toolShapeSVG[session.currentSubTool] || session.currentSubTool,
        o: session.currentSetProp.opacity || 1,
        x: x - (session.inserting.w/2),
        y: y - (session.inserting.h/2)
      }});
      session.inserting = null;
      sendAnnotationUpdate(renderAnno);
      //saveChange(renderAnno);
      renderItem(renderAnno);
      toolFunctions.selectInit(renderAnno.id, e);
    }
    createListener(docHolder, "mousedown", mouseDown);
    createListener(docHolder, "touchstart", mouseDown);
  }
}