let joinModal = findC("join-modal");

let joinInputCodeHolder = findC("join-input-code-holder");
let joinCodeInput = findC("join-code-input");
let joinCodeNext = findI("join-code-next");

let joinDivideLine = findC("horizontal-line");

let joinInputNameHolder = findI("join-input-name-holder");
let joinNameInput = findC("join-name-input");
let joinNameJoin = findI("join-name-join");

joinCodeInput.addEventListener("input", function() {
  joinInputCodeHolder.style.backgroundColor = "var(--grayColor)";
});
joinNameInput.addEventListener("input", function() {
  joinInputNameHolder.style.backgroundColor = "var(--grayColor)";
});
async function joinCodeNextF() {
  let code = joinCodeInput.value;
  let valid = true;
  if (code.length != 6) {
    valid = false;
  } else if (code.match(/^[0-9]+$/) == null) {
    valid = false;
  }
  if (valid != false) {
    let [ status ] = await sendRequest("GET", "checkcode?code=" + code);
    if (status != 200) {
      valid = false;
    }
  }
  if (valid == false) {
    joinInputCodeHolder.style.backgroundColor = "var(--errorRed)";
    forceClickElement(joinCodeInput);
    return;
  }
  if (account.id == null) {
    joinCodeNext.style.display = "none";
    joinCodeInput.style.width = "100%";
    joinCodeInput.style.borderRadius = "10px";
    joinInputCodeHolder.style.backgroundColor = "var(--grayColor)";
    joinDivideLine.style.display = "block";
    joinInputNameHolder.style.display = "flex";
    forceClickElement(joinNameInput);
  } else {
    setWireframe("edit");
    mainLoadActions.main(null, null, { code: joinCodeInput.value });
  }
}
joinCodeNext.addEventListener("click", joinCodeNextF);
joinCodeInput.addEventListener("keyup", function(e) {
  if (e.key == "Enter") {
    joinCodeNextF();
  }
});

function joinNameJoinF() {
  let name = joinNameInput.value;
  let valid = true;
  if (name.length < 1 || name.length > 24) {
    valid = false;
  } else if (name.replace(/[^A-Za-z0-9\!\@\#\$\%\^\&\*\(\)\_\-\=\+\"\'\~\?`]/g, "") != name) {
    valid = false;
  }
  if (valid == false) {
    joinInputNameHolder.style.backgroundColor = "var(--errorRed)";
    forceClickElement(joinNameInput);
    return;
  }
  setWireframe("edit");
  mainLoadActions.main(null, null, { code: joinCodeInput.value, name: joinNameInput.value });
}
joinNameJoin.addEventListener("click", joinNameJoinF);
joinNameInput.addEventListener("keyup", function(e) {
  if (e.key == "Enter") {
    joinNameJoinF();
  }
});

loadScript("../pdfjs/build/pdf.js");
loadScript("main.js");
loadScript("live.js");
loadScript("toolbar.js");