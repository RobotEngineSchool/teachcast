wireframes.login = `<div class="background"> <div class="login-modal"> <img class="auth-product-logo" src="./images/productlogodark.svg"></img> <div class="sign-in-with-tx">Sign in with...</div> <div class="sign-in-option" id="exotek" style="background-color: #000"> <img class="sign-in-logo" src="./images/home/oauthicons/exotek.png"></img> <div class="sign-in-name">Exotek</div> </div> <div class="horizontal-line"></div> <div class="sign-in-option" id="google" style="background-color: #1E75B8"> <img class="sign-in-logo" src="./images/home/oauthicons/google.png"></img> <div class="sign-in-name">Google</div> </div> <div class="sign-in-option" id="microsoft" style="background-color: #51C729"> <img class="sign-in-logo" src="./images/home/oauthicons/microsoft.png"></img> <div class="sign-in-name">Microsoft</div> </div> <div class="tos-privacy-holder"> <a class="policy-button" href="https://exotek.co/tos" target="_blank">Terms of Service</a> <a class="policy-button" href="https://exotek.co/privacy" target="_blank">Privacy Policy</a> </div> </div> </div>`;
wireframes.home = `<div class="home-top-bar"> <div class="product-logo"></div> <div class="home-center-holder"> <div class="home-create-new-button" onclick='renderDropdown(this, dropdowns.newDoc)'> <div class="home-new-button-img"></div> <div class="dropdown-button-text" id="home-new-button-tx">New File</div> </div> <input class="home-search-files" placeholder="Search Files..."></input> <div class="home-sort-dropdown" onclick='renderDropdown(this, dropdowns.sort)'> <div class="dropdown-button-text" id="dropdown-recent-sort">Recent</div> <div class="dropdown-arrow"></div> </div> </div> <img class="account-profile-image"></img> </div> <div class="home-doc-holder"></div>`;
wireframes.tile = `<div class="home-tile" onclick="openDoc('DOC_ID')"> <img class="home-tile-preview-img" src="IMAGE_URL"></img> <div class="home-tile-file-name">DOC_NAME</div> <div class="home-tile-last-open">LAST_EDIT</div> </div>`;
wireframes.userinfo = `<img class="profile-info-img" src="IMAGE_URL"></img> <div class="profile-info-detail-holder"> <div class="profile-info-user">USERNAME</div> <div class="profile-info-email">EMAIL</div> <div class="profile-info-manage-account"> <div class="profile-info-manage-button" id="profile-info-logout">Logout</div> <div class="profile-info-manage-button" id="profile-info-settings">Settings</div> </div> </div>`;

let pages = {};

pages.signIn = function() {
  setWireframe("login");
  let oauthID = randomString();
  let oauthOptions = {
    "exotek": "",
    "google": "https://accounts.google.com/o/oauth2/v2/auth?client_id=349784778364-s5f7616dhijiqvqqo6u0md2qsnid1qqn.apps.googleusercontent.com&redirect_uri=https%3A%2F%2Fteachcast-p5of2.ondigitalocean.app%2Fapi%2Foauth%2Fgoogle&response_type=code&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email&state=" + oauthID,
    //"google": "https://accounts.google.com/o/oauth2/v2/auth?client_id=349784778364-s5f7616dhijiqvqqo6u0md2qsnid1qqn.apps.googleusercontent.com&redirect_uri=https%3A%2F%2Fexotek.co%2Fteachcast%2Fapi&response_type=code&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile&state=" + randomString(),
    "microsoft": ""
  };
  
  let authOptions = document.getElementsByClassName("sign-in-option");
  for (let i = 0; i < authOptions.length; i++) {
    authOptions[i].onclick = function(e) {
      let left = (screen.width/2)-(500/2);
      let top = (screen.height/2)-(750/2) - 50;
      window.open(oauthOptions[this.id], "authenticate", "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=500, height=750, top=" + top + ", left=" + left);
    }
  }

  simpleSocketListeners.push(SimpleSocket.subscribeEvent({ type: "auth", id: oauthID }, function(data) {
    // Sign in user:
    localStorage.setItem("userID", data.user.id);
    localStorage.setItem("token", JSON.stringify(data.token));
    account = data.user;
    pages.home();
  }));
}
let currentSort = "Recent";
pages.home = async function() {
  setWireframe("home");
  let profilePic = findC("account-profile-image");
  profilePic.src = account.image;
  profilePic.addEventListener("click", function() {
    let dispElem = createElement("profile-info-holder", "div", dropdownFrameHolder);
    dispElem.innerHTML = wireframes.userinfo.replace(/IMAGE_URL/g, account.image).replace(/USERNAME/g, account.user).replace(/EMAIL/g, account.email);
    setKeepElem(dispElem);
    findI("profile-info-logout").addEventListener("click", async function() {
      dispElem.remove();
      let [ status, response ] = await sendRequest("HEAD", "logout");
      if (status == 200) {
        localStorage.removeItem("userID");
        localStorage.removeItem("token");
        location.reload();
      }
    });
  });
  
  let docItemHolder = findC("home-doc-holder");
  function addTiles(newTiles, clear) {
    let appendInner = "";
    if (clear != true) {
      appendInner += docItemHolder.innerHTML;
    }
    for (let i = 0; i < newTiles.length; i++) {
      let tileData = newTiles[i];
      let openedDate = new Date(tileData.opened || tileData.created).getTime();
      var calcTime = Math.floor((Date.now() - openedDate) / 1000);
      if (calcTime < 1) {
        calcTime = 1; // Prevent negative timestamps.
      }
      var amDivide = 1;
      var end = "Second";
      if (calcTime > 31536000-1) {
        amDivide = 31536000;
        end = "Year";
      } else if (calcTime > 2592000-1) {
        amDivide = 2592000;
        end = "Month";
      } else if (calcTime > 604800-1) {
        amDivide = 604800;
        end = "Week";
      } else if (calcTime > 86400-1) {
        amDivide = 86400;
        end = "Day";
      } else if (calcTime > 3600-1) {
        amDivide = 3600;
        end = "Hour";
      } else if (calcTime > 60-1) {
        amDivide = 60;
        end = "Minute";
      }
      var timeToSet = Math.floor(calcTime / amDivide);
      if (timeToSet > 1) {
        end += "s";
      }
      appendInner += wireframes.tile.replace(/DOC_ID/g, tileData._id).replace(/IMAGE_URL/g, tileData.preview || "./images/testpreview.png").replace(/DOC_NAME/g, tileData.name || "Untitled Document").replace(/LAST_EDIT/g, timeToSet + " " + end + " Ago");
    }
    docItemHolder.innerHTML = appendInner;
  }
  let path = "docs";
  if (SimpleSocket.SecureID != null) {
    path += "?ss=" + SimpleSocket.SecureID;
  }
  let [ status, response ] = await sendRequest("GET", path);
  if (status == 200) {
    let tiles = JSON.parse(response);
    if (tiles.length > 0) {
      addTiles(tiles, true);
    } else {
      createElement("no-docs-img", "img", docItemHolder).src = "./images/home/icons/uploadfile.svg";
      createElement("no-docs-message", "div", docItemHolder).textContent = "You don't have any documents yet! Create one above!";
    }
  }
}
function setSort(sort) {
  currentSort = sort;
  let dropSort = findI("dropdown-recent-sort");
  if (dropSort != null) {
    dropSort.textContent = sort;
  }
  removeMainDropdown();
}
function openDoc(docID) {
  pages.editDoc(docID);
}
async function createNewDoc(type) {
  removeMainDropdown();
  if (type == "upload") {
    let actualUploadInput = createElement("actualUploadInput", "input", body, {
      "position": "absolute",
      "height": "0%",
      "width": "0%",
      "left": "0px",
      "top": "0px"
    });
    actualUploadInput.setAttribute("type", "file");
    actualUploadInput.setAttribute("accept", "application/*");
    actualUploadInput.setAttribute("hidden", "true");
    actualUploadInput.setAttribute("multiple", "true");
    actualUploadInput.addEventListener("change", async function(e) {
      let sendFormData = new FormData();
      sendFormData.append("name", e.target.files[0].name);
      for (let i = 0; i < e.target.files.length; i++) {
        let blob = URL.createObjectURL(e.target.files[i]);
        await fetch(blob).then(async function (file) {
          sendFormData.append("file" + i, await file.blob());
          URL.revokeObjectURL(blob);
        });
      }
      let [ status, response ] = await sendRequest("POST", "new?ss=" + SimpleSocket.SecureID, sendFormData, true);
      if (status == 200) {
        let data = JSON.parse(response);
        pages.editDoc(data._id, data.url, { name: data.name });
      }
    });
    actualUploadInput.click();
  } else {
    let [ status, response ] = await sendRequest("POST", "new?ss=" + SimpleSocket.SecureID);
    if (status == 200) {
      let data = JSON.parse(response);
      pages.editDoc(data._id, data.url, { name: data.name });
    }
  }
}

pages.editDoc = async function(docID, url, data) {
  setWireframe("edit");
  mainLoadActions.main(docID, url, data);
}

function runInit() {
  if (account.email != null) {
    pages.home();
  } else {
    pages.signIn();
  }
}
if (finishedInit == true) {
  runInit();
}

loadScript("../pdfjs/build/pdf.js");
loadScript("main.js");
loadScript("live.js");
loadScript("toolbar.js");