// Global Items Here:
let sendMemberUpdate;
let sendAnnotationUpdate;
let saveChange;
///////////////////

let cursorTypes = {
  select: {
    img: '<svg viewBox="0 0 158 204" fill="none" xmlns="http://www.w3.org/2000/svg"> <mask id="mask0_515_31" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="158" height="204"> <rect width="158" height="204" fill="#C4C4C4"/> </mask> <g mask="url(#mask0_515_31)"> <path d="M88.6882 119.764L65.5221 131.568C57.6486 135.58 54.5181 145.215 58.5298 153.088L75.9217 187.222C79.9334 195.095 89.5682 198.226 97.4417 194.214L120.608 182.41C128.481 178.398 131.612 168.764 127.6 160.89L110.208 126.757C106.196 118.883 96.5616 115.753 88.6882 119.764Z" fill="COLLAB_COLOR" stroke="white" stroke-width="12"/> <path d="M143.355 90.0789L32.4076 9.87985C21.8414 2.24204 7.06594 9.77055 7.03442 22.8081L6.70347 159.706C6.67454 171.671 19.3071 179.433 29.9673 174.001L141.246 117.302C151.906 111.87 153.051 97.0878 143.355 90.0789Z" fill="COLLAB_COLOR" stroke="white" stroke-width="12"/> <path d="M59.3521 141.446L100.325 120.569L119.16 157.535L78.1871 178.412L59.3521 141.446Z" fill="COLLAB_COLOR"/> </g> </svg>'
  },
  annotate: {
    img: '<svg viewBox="0 0 145 221" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M52.3895 168.528L46.6517 170.282L44.8975 164.544L7.47933 42.1549C4.7343 33.1763 9.78759 23.6724 18.7662 20.9274L62.7562 7.47826C71.7348 4.73323 81.2387 9.78653 83.9837 18.7651L121.402 141.154L123.156 146.892L117.418 148.646L52.3895 168.528Z" fill="COLLAB_COLOR" stroke="white" stroke-width="12"/> <mask id="mask0_586_2" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="39" y="150" width="106" height="71"> <path d="M145 191.905L52.3581 220.322L39.65 178.618L132.292 150.2L145 191.905Z" fill="COLLAB_COLOR"/> </mask> <g mask="url(#mask0_586_2)"> <path d="M117.109 141.818L125.668 139.192L124.829 148.111L121.476 183.727C120.932 189.509 116.626 194.235 110.924 195.309L81.4257 200.866C77.1301 201.675 72.7193 200.269 69.6867 197.125L46.1438 172.71L39.3537 165.669L48.7126 162.798L117.109 141.818Z" fill="COLLAB_COLOR" stroke="white" stroke-width="12"/> </g> <path d="M105.29 190.25L86.6699 193.718L92.0479 216.297L110.171 216.46L105.29 190.25Z" fill="SELECTED_COLOR"/> </svg>',
    left: -10,
    top: -20,
    hasColor: true
  },
  draw: {
    img: '<svg viewBox="0 0 141 238" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M48.5746 169.067L42.8367 170.821L41.0825 165.084L7.89674 56.5379C1.60675 35.9643 13.1859 14.187 33.7596 7.89698C54.3332 1.60699 76.1105 13.1862 82.4005 33.7598L115.586 142.306L117.34 148.043L111.603 149.798L48.5746 169.067Z" fill="COLLAB_COLOR" stroke="white" stroke-width="12"/> <mask id="mask0_589_9" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="35" y="150" width="106" height="68"> <path d="M140.258 189.579L47.6164 217.997L35.7997 179.217L128.442 150.8L140.258 189.579Z" fill="COLLAB_COLOR"/> </mask> <g mask="url(#mask0_589_9)"> <path d="M110.948 147.219L119.787 144.517L118.658 153.69L113.848 192.755L113.372 196.622L109.646 197.76L80.04 206.806L76.5773 207.864L74.0272 205.294L45.415 176.452L38.414 169.395L47.9203 166.489L110.948 147.219Z" fill="COLLAB_COLOR" stroke="white" stroke-width="12"/> </g> <path d="M104.003 193.244L82.0632 199.952L86.104 213.169C87.9562 219.227 94.3692 222.637 100.428 220.785V220.785C106.486 218.932 109.896 212.519 108.044 206.461L104.003 193.244Z" fill="SELECTED_COLOR"/> </svg>',
    left: -10,
    top: -20,
    hasColor: true
  },
  eraser: {
    img: '<svg viewBox="0 0 155 178" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M69.0767 17.2412L17.2068 48.9027L86.6395 162.652L138.509 130.99L69.0767 17.2412Z" fill="COLLAB_COLOR"/> <path d="M63.3667 13.934L16.9062 42.2936C12.6636 44.8833 11.3236 50.422 13.9133 54.6647L71.1381 148.414C78.3318 160.199 93.7171 163.921 105.502 156.727L138.306 136.704C142.548 134.114 143.888 128.576 141.299 124.333L75.7378 16.9269C73.1481 12.6842 67.6094 11.3443 63.3667 13.934Z" stroke="white" stroke-width="12"/> </svg>',
    left: -10,
    top: -20
  },
  text: {
    img: '<svg viewBox="0 0 114 201" fill="none" xmlns="http://www.w3.org/2000/svg"> <rect x="41.3755" y="34.8843" width="31.2486" height="140" rx="12" fill="COLLAB_COLOR" stroke="white" stroke-width="12"/> <rect x="6" y="6.76855" width="102" height="31.25" rx="12" fill="COLLAB_COLOR" stroke="white" stroke-width="12"/> <rect x="6" y="163.624" width="102" height="31.25" rx="12" fill="COLLAB_COLOR" stroke="white" stroke-width="12"/> <rect x="47" y="32" width="20" height="140" fill="COLLAB_COLOR"/> </svg>',
    left: -5,
    top: -10
  }
};

mainLoadActions.live = function actionInitLive() {
  SimpleSocket.remoteFunctions.update = function(data) {
    switch (data.e) {
      case "name":
        let docName = findC("document-name");
        if (docName != null) {
          docName.textContent = data.name;
        }
        break;
      case "code":
        session.shareCode = data.code;
        let codeOnBar = findC("share-code-display");
        if (codeOnBar != null) {
          if (session.shareCode != null) {
            codeOnBar.textContent = session.shareCode;
            codeOnBar.style.display = "block";
          } else {
            codeOnBar.style.display = "none";
          }
        }
        let codeInShare = findC("modal-share-code");
        if (codeInShare != null) {
          if (session.shareCode != null) {
            codeInShare.textContent = session.shareCode;
            findC("modal-share-new-c").textContent = "Remove";
            findC("modal-share-new-c").style.backgroundColor = "var(--errorRed)";
            findI("view-share-code-fullscreen").hidden = false;
            findI("copy-share-code").hidden = false;
          } else {
            codeInShare.textContent = "";
            findC("modal-share-new-c").textContent = "Generate";
            findC("modal-share-new-c").style.backgroundColor = "var(--brightBlue)";
            findI("view-share-code-fullscreen").hidden = true;
            findI("copy-share-code").hidden = true;
          }
        }
        let codeFullscreen = findC("fullscreen-code");
        if (codeFullscreen != null) {
          if (session.shareCode == null) {
            findI("fullscreen-modal").parentElement.remove();
          } else {
            codeFullscreen.textContent = session.shareCode;
          }
        }
        break;
    }
  };

  let memberAmCounters = document.getElementsByClassName("view-members-amount");
  let updateLiveCounters = function updateLiveCounters() {
    let memberAm = Object.keys(session.live.members).length - 1;
    for (let i = 0; i < memberAmCounters.length; i++) {
      let currentCounter = memberAmCounters[i];
      if (memberAm > 0) {
        currentCounter.textContent = memberAm;
        currentCounter.style.display = "inline";
      } else {
        currentCounter.style.display = "none";
      }
    }
  }
  SimpleSocket.remoteFunctions.member = function(data) {
    switch (data.e) {
      case "join":
        data.set._id = data.ssid;
        session.live.members[data.ssid] = data.set;
        createLiveMemberTile(data.set, findI("dropdown-members-list"));
        break;
      case "leave":
        let member = session.live.members[data.ssid];
        if (member == null) {
          break;
        }
        let userCursor = findI(data.ssid + "-cursor");
        if (userCursor != null) {
          userCursor.remove();
        }
        let userSelectionHolder = findI(data.ssid + "-selections");
        if (userSelectionHolder != null) {
          userSelectionHolder.remove();
        }
        let remSelBox = findI(data.ssid + "-selectionBox");
        if (remSelBox != null) {
          remSelBox.remove();
        }
        delete session.live.members[data.ssid];
        let memberTile = findI("member-tile-" + data.ssid);
        if (memberTile != null) {
          let tileHolder = memberTile.parentElement;
          memberTile.remove();
          tileHolder.parentElement.style.height = tileHolder.clientHeight + 4 + "px";
        }
        break;
    }
    updateLiveCounters();
  };
  updateLiveCounters();

  function syncAnnotations(anno, recTime, memberData, cursorData, config, userCursor, liveUserSelectionBox) {
    if (anno.p != true) {
      let oldSession = session.annotations[anno.id];
      if (oldSession != null && oldSession.local != null) {
        if (oldSession.local.lastRec > recTime || recTime == null) {
          return;
        }
        anno.local = oldSession.local;
        if (session.editing == true && oldSession != null) {
          anno.w = oldSession.w;
          anno.h = oldSession.h;
          anno.x = oldSession.x;
          anno.y = oldSession.y;
        }
        if (memberData != null && cursorData.tool == "select") {
          if (liveUserSelectionBox == null) {
            liveUserSelectionBox = createElement("live-selection-box", "div", annotationsHolder, { "background-color": (memberData.c || "#000000") + "15", "border-color": (memberData.c || "#000000") + "99" });
          }
          liveUserSelectionBox.id = config.publisherID + "-selectionBox";
          liveUserSelectionBox.setAttribute("annoID", anno.id);
        }
      } else {
        if (liveUserSelectionBox != null) {
          liveUserSelectionBox.remove();
        }
      }
      if (userCursor != null) {
        let floatingAnno = userCursor.querySelector(".floating-annotation");
        if (floatingAnno != null) {
          floatingAnno.remove();
        }
      }
    } else {
      if (userCursor != null) {
        let floatingAnno = userCursor.querySelector(".floating-annotation");
        if (floatingAnno != null) {
          anno.elem = floatingAnno;
        }
        anno.sol = userCursor;
      }
    }
    //if (session.editing != true) {
    if (anno.local == null) {
      anno.local = {};
    }
    anno.local.lastRec = recTime;
    session.annotations[anno.id] = anno;
    if (session.inserting != null && session.inserting.id == anno.id) {
      session.inserting = anno;
    }
    renderItem(anno);
    //}
  }
  
  SimpleSocket.remoteFunctions.fast = function(data, config) {1
    if (config.publisherID == SimpleSocket.ClientID) {
      return;
    }
    switch (data.e) {
      case "memed":
        let memberData = session.live.members[config.publisherID];
        if (memberData == null) {
          session.live.members[config.publisherID] = {}; // REMOVE LINE LATER
          memberData = session.live.members[config.publisherID]; // REMOVE LINE LATER
          //break; // ADD BACK LATER
        }
        let cursorData = memberData.cursor || {};
        if (cursorData.lastRec > data.q || data.q == null) {
          cursorData = null;
        }
        let rect = docHolder.getBoundingClientRect();
        let scrollWidth = getScrollWidth();
        let scrollHeight = getScrollHeight();
        let userCursor = findI(config.publisherID + "-cursor");
        if (cursorData != null && (cursorData.tool != data.t || cursorData.color != data.c || cursorData.x != data.x || cursorData.y != data.y)) {
          let cursorChanged = cursorData.tool != data.t || cursorData.color != data.c;
          cursorData.tool = data.t;
          cursorData.x = session.zoom * (data.x + rect.x + scrollWidth);
          cursorData.y = session.zoom * (data.y + rect.y) + scrollHeight;
          let setX = cursorData.x;
          let setY = cursorData.y;
          let cursorImg = (cursorTypes[cursorData.tool] || cursorTypes.select);
          if (cursorImg.left != null) {
            setX += cursorImg.left;
          }
          if (cursorImg.top != null) {
            setY += cursorImg.top;
          }
          if (userCursor != null) {
            cursorData.cursor = userCursor;
            if (userCursor.getAttribute("tool") != cursorData.tool) {
              userCursor.setAttribute("tool", cursorData.tool);
              userCursor.innerHTML = cursorImg.img.replace(/COLLAB_COLOR/g, memberData.c || "#000000");
            }
          } else {
            userCursor = createElement("live-cursor", "div", "static-holder");
            cursorData.cursor = userCursor;
            userCursor.id = config.publisherID + "-cursor";
            userCursor.setAttribute("tool", cursorData.tool);
          }
          if (cursorChanged == true) {
            userCursor.innerHTML = cursorImg.img.replace(/SELECTED_COLOR/g, cursorData.color || "#000000").replace(/COLLAB_COLOR/g, memberData.c || "#000000");
          }
          //userCursor.style.transition = "all " + Math.sqrt(Math.pow(setX - oldX, 2) + Math.pow(setY - oldY, 2))/cursorSpeed + "s ease";
          userCursor.style.left = setX + "px";
          userCursor.style.top = setY + "px";
        }
        let userSelectionHolder = findI(config.publisherID + "-selections");
        if (userSelectionHolder != null) {
          userSelectionHolder.remove();
        }
        if (data.s != null) {
          userSelectionHolder = createElement("live-selections", "div", "static-holder");
          userSelectionHolder.id = config.publisherID + "-selections";
          for (let i = 0; i < data.s.length; i++) {
            let selectD = data.s[i];
            createElement("live-selection", "div", userSelectionHolder, { width: (session.zoom*selectD.w) + "px", height: (session.zoom*selectD.h) + "px", left: session.zoom*(selectD.x + rect.x + scrollWidth) + "px", top: session.zoom*(selectD.y + rect.y) + scrollHeight + "px", "background-color": memberData.c || "#000000" });
          }
        }
        let liveUserSelectionBox = findI(config.publisherID + "-selectionBox");
        if (data.i != null) {
          syncAnnotations(data.i, data.q, memberData, cursorData, config, userCursor, liveUserSelectionBox);
        } else {
          if (userCursor != null) {
            let floatingAnno = userCursor.querySelector(".floating-annotation");
            if (floatingAnno != null) {
              floatingAnno.remove();
            }
          }
          if (liveUserSelectionBox != null) {
            liveUserSelectionBox.remove();
          }
        }
        session.live.members[config.publisherID].cursor = cursorData;
        break;
      case "anoup":
        if (typeof data.a == "string") {
          deleteAnnotation(data.a);
          return;
        }
        syncAnnotations(data.a, data.q);
    }
  }

  SimpleSocket.remoteFunctions.long = function(data) {
    if (typeof data == "string") {
      deleteAnnotation(data);
      return;
    }
    syncAnnotations(data.a, data.q);
  }
  
  function formatDocPublish(page, data) {
    if (page == null) {
      page = session.currentPage;
    }
    let filter = { type: "fast", id: session.id };
    if (page != false) {
      filter.pages = page;
    }
    data.q = getEpoch();
    SimpleSocket.publishEvent(filter, data);
  }
  
  sendMemberUpdate = function sendMemberUpdate(ignorePerm, sendData) {
    if (ignorePerm != true) {
      if (session.permisions.includes("edit") == false) {
        return;
      }
    }
    sendData = sendData || {};
    sendData.e = "memed";
    if (session.mouse.selections.length > 0) {
      sendData.s = session.mouse.selections;
    }
    let cursorData = cursorTypes[session.currentTool];
    if (session.currentTool != "Select" && cursorData != null) {
      sendData.t = session.currentTool;
      if (cursorData.hasColor == true) {
        sendData.c = session.currentSetProp.color;
      }
    }
    if (session.inserting != null) {
      let sendIns = { ...session.inserting };
      if (sendIns.local != null) {
        delete sendIns.local;
      }
      sendData.i = sendIns;
    }
    session.live.lastSendMouse.s = session.mouse.selections.length;
    formatDocPublish(false, sendData);
  }
  
  sendAnnotationUpdate = function sendAnnotationUpdate(annotation) {
    formatDocPublish(false, { e: "anoup", a: annotation });
  }
  
  saveChange = async function saveChange(annotation) {
    let sendAnno = annotation;
    if (typeof annotation == "object") {
      sendAnno = { ...annotation };
      if (sendAnno.local != null) {
        delete sendAnno.local;
      }
      if (sendAnno.doc != null) {
        delete sendAnno.doc;
      }
      if (sendAnno.user != null) {
        delete sendAnno.user;
      }
      if (sendAnno.time != null) {
        delete sendAnno.time;
      }
      if (annotation.local == null) {
        annotation.local = {};
      }
      let hashStr = hash(JSON.stringify(sendAnno));
      if (annotation.local.hash == hashStr) {
        setSaveStatus("saved");
        return;
      }
      annotation.local.hash = hashStr;
    }
    setSaveStatus("saving");
    let [ status ] = await sendRequest("PUT", "save?doc=" + session.id, [sendAnno]);
    if (status == 200) {
      setSaveStatus("saved");
    } else {
      
    }
  }
  
  let runningEditLoop = false;
  async function startCursorForEdit() {
    if (runningEditLoop == true) {
      return;
    }
    runningEditLoop = true;
    while (session.permisions.includes("edit")) { // && Object.keys(session.live.members).length > 1
      await sleep(80);
      let sendData = {};
      if (session.live.lastSendMouse.x != session.mouse.x) {
        sendData.x = session.mouse.x;
        session.live.lastSendMouse.x = session.mouse.x;
      }
      if (session.live.lastSendMouse.y != session.mouse.y) {
        sendData.y = session.mouse.y;
        session.live.lastSendMouse.y = session.mouse.y;
      }
      if (session.live.lastSendMouse.s != session.mouse.selections.length) {
        sendData.s = [];
      }
      if (Object.keys(sendData).length > 0) {
        sendMemberUpdate(true, sendData);
      }
    }
    runningEditLoop = false;
  }
  startCursorForEdit();
  
  function setMousePos(x, y) {
    let mouseData = session.mouse;
    if (x != null && y != null) {
      // Send mouse data:
      // Convert the local mouse data to a format that works with any scaling/zooming combination on any screen size:
      mouseData = scaleToDoc(x, y);
    }
    
    let addTextSelect = [];
    if (window.getSelection != null) {
      let select = window.getSelection();
      if (select.rangeCount > 0) {
        let range = select.getRangeAt(0);
        if (range.toString().length > 0 && range.endContainer.parentNode.getAttribute("role") == "presentation") {
          let selections = range.getClientRects();
          let addedPrev = [];
          let rect = docHolder.getBoundingClientRect();
          let scaleZoom = 1/session.zoom;
          for (let i = 0; i < selections.length; i++) {
            let selRect = selections[i];
            let selData = { w: Math.floor(selRect.width), h: Math.floor(selRect.height), x: Math.floor(((selRect.x*session.zoom) - (rect.left*session.zoom))*scaleZoom), y: Math.floor(((selRect.y*session.zoom) - (rect.top*session.zoom))*scaleZoom) };
            if (selData.w > 0 && addedPrev.includes(selData.w + selData.x) == false) {
              addedPrev.push(selData.w + selData.x);
              addTextSelect.push(selData);
            }
          }
        }
      }
    }
    mouseData.selections = addTextSelect;
    
    session.mouse = mouseData;
  }
  tempListen(window, "mousemove", function(e) {
    setMousePos(e.x, e.y);
  });
  tempListen(document, "touchmove", function(e) {
    setMousePos(e.touches[0].clientX, e.touches[0].clientY);
  });
  tempListen(document, "touchstart", function(e) {
    setMousePos(e.touches[0].clientX, e.touches[0].clientY);
  });
  tempListen(document, "mouseup", function(e) {
    setMousePos(e.x, e.y);
  });
}