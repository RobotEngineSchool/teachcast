let serverURL = "https://teachcast-p5of2.ondigitalocean.app/api/";
//let serverURL = "http://localhost:3000/api/";
let assetURL = "https://teachcast.s3.amazonaws.com/";

let wireframes = {};

let account = {};
let currentEditID = null;

let mainLoadActions = [];
let simpleSocketListeners = [];

SimpleSocket.connect({
  project_id: "62088fbdfc22489578e94822",
  client_token: "client_129dbf2cf03edc6fba2aac135fd5ae119af"
});

let tempListeners = [];
function tempListen(parent, listen, runFunc, extra) {
  parent.addEventListener(listen, runFunc, extra);
  tempListeners.push({ parent: parent, name: listen, listener: runFunc });
}
function removeTempListeners() {
  for (let i = 0; i < tempListeners.length; i++) {
    let remEvent = tempListeners[i];
    if (remEvent.parent != null) {
      remEvent.parent.removeEventListener(remEvent.name, remEvent.listener);
    }
  }
}

function findC(name) {
  return document.getElementsByClassName(name)[0];  
}
function findI(name) {
  return document.getElementById(name);  
}

let body = findC("body");

let app = findI("app");
function setWireframe(name) {
  app.innerHTML = wireframes[name];
  removeMainDropdown();
  removeTempListeners();
  for (let i = 0; i < simpleSocketListeners.length; i++) {
    SimpleSocket.closeSubscribe(simpleSocketListeners[i]);
  }
  simpleSocketListeners = [];
}

function createElement(ElementName, ElementType, SetParent, Attributes, NS) {
  "use strict";

  if (Attributes == null) {
    Attributes = [];
  }

  let AttributeKeys = Object.keys(Attributes);

  if (SetParent == null) {
    return null;
  } else {
    if (typeof SetParent === "string" || typeof SetParent === "number") {
      SetParent = findC(SetParent);
    }
  }

  let NewElement,
    StyleApply = "",
    i;

  if (NS == null) {
    NewElement = document.createElement(ElementType);
  } else {
    NewElement = document.createElementNS(NS, ElementType);
  }

  if (SetParent === null) {
    document.body.appendChild(NewElement);
  } else {
    SetParent.appendChild(NewElement);
  }

  for (i = 0; i < AttributeKeys.length; i += 1) {
    StyleApply = StyleApply + AttributeKeys[i] + ": " + Attributes[AttributeKeys[i]] + "; ";
  }
  NewElement.setAttribute("style", StyleApply);
  NewElement.setAttribute("class", ElementName);

  return NewElement;
}
const sleep=(milliseconds)=>{return new Promise(resolve=>setTimeout(resolve,milliseconds));}

function getScript(ScriptUrl) {
  return document.getElementById(ScriptUrl);
}
async function loadScript(ScriptUrl) {
  return new Promise(function (resolve, reject) {
    let AlreadyLoadedScript = getScript(ScriptUrl);
    if (AlreadyLoadedScript != null) {
      AlreadyLoadedScript.remove();
    }
  
    let LoadScript = document.createElement('script');
    LoadScript.addEventListener("load", function() {
      resolve(LoadScript);
    });
    LoadScript.src = ScriptUrl;
    LoadScript.id = ScriptUrl;
    document.body.appendChild(LoadScript);
  });
}

function randomString() {
  var S4 = function() {
    return (((1+Math.random())*0x10000)|0).toString(16).substring(1);
  };
  let retStr = "";
  for (let i = 0; i < 20; i++) {
    retStr += S4();
  }
  return retStr;
}

let themeColor = "#228EF2";

let dropdowns = {
  file: [
    ["Download File", "exportFile", null, "./images/icons/export.svg"],
    ["Create a Copy", [
      ["Create Copy with Edits", "createCopyWithEdits", null, "./images/icons/copy.svg"],
      ["Create Copy of Original", [
        ["Create Copy with Edits", "createCopyWithEdits", null, "./images/icons/copy.svg"],
        ["Create Copy of Original", "createCopyOfOriginal", null, "./images/icons/copy.svg"]
      ], null, "./images/icons/copy.svg"]
    ], null, "./images/icons/copy.svg"],
    ["Print", [
      ["Create Copy with Edits", [
        ["Create Copy with Edits", "createCopyWithEdits", null, "./images/icons/copy.svg"],
        ["Create Copy of Original", "", null, "./images/icons/copy.svg"]
      ], null, "./images/icons/copy.svg"],
      ["Create Copy of Original", [
        ["Create Copy with Edits", "createCopyWithEdits", null, "./images/icons/copy.svg"],
          ["Create Copy of Original", [
            ["Create Copy with Edits", "createCopyWithEdits", null, "./images/icons/copy.svg"],
            ["Create Copy of Original", "createCopyOfOriginal", null, "./images/icons/copy.svg"]
        ], null, "./images/icons/copy.svg"]
      ], null, "./images/icons/copy.svg"]
    ], null, "./images/icons/print.svg"],
    "LINEBREAK",
    ["History", "viewFileHistory", null, "./images/icons/history.svg"],
    ["Properties", "viewDocumentStats", null, "./images/icons/properties.svg"],
    "LINEBREAK",
    ["Run OCR", "runOCR", null, "./images/icons/ocr.svg"], 
    "LINEBREAK",
    ["Find", "findInFile", null, "./images/icons/magnifying.svg"],
    ["Jump to Page", "jumpToPage", null, "./images/icons/pagejump.svg"]
  ],
  zoom: [
    ["+20% Zoom", "addZoomLevel", 0.2, "./images/icons/zoominmagnifying.svg"],
    ["+10% Zoom", "addZoomLevel", 0.1, "./images/icons/zoominmagnifying.svg"],
    ["+5% Zoom", "addZoomLevel", 0.05, "./images/icons/zoominmagnifying.svg"],
    ["Reset Zoom", "setZoomLevel", 1, "./images/icons/magnifying.svg"],
    ["-5% Zoom", "addZoomLevel", -0.05, "./images/icons/zoomoutmagnifying.svg"],
    ["-10% Zoom", "addZoomLevel", -0.1, "./images/icons/zoomoutmagnifying.svg"],
    ["-20% Zoom", "addZoomLevel", -0.2, "./images/icons/zoomoutmagnifying.svg"],
    "LINEBREAK",
    ["Hide Cursors", "setDocOption", "hideCursor", "./images/toolbar/cursor.svg"],
    ["Hide Comments", "setDocOption", "hideComments", "./images/toolbar/notes.svg"],
    "LINEBREAK",
    ["Fullscreen", "openFullscreen", null, "./images/icons/fullscreen.svg"],
  ],
  
  sort: [
    ["Recent", "setSort"],
    ["By Me", "setSort"],
    ["By Others", "setSort"],
    ["Creation", "setSort"]
  ],
  newDoc: [
    ["Upload Document", "createNewDoc", "upload", "./images/home/icons/uploadfile.svg"],
    ["Create Blank", "createNewDoc", "blank", "./images/home/icons/newfile.svg"]
  ]
};

let dropdownFrameHolder = findC("dropdown-frame-holder");
let prevDropdownParent = null;
let prevPrevDropdownParent = null;
async function removeSubDropdowns(mainDropdown) {
  mainDropdown = mainDropdown || dropdownFrameHolder.querySelector(".dropdown-frame").querySelector(".dropdown-element");
  if (mainDropdown == null) {
    return;
  }
  let currentDropdownID = mainDropdown.getAttribute("subdropdown");
  while (findI(currentDropdownID) != null) {
    let dropdown = findI(currentDropdownID);
    currentDropdownID = dropdown.querySelector(".dropdown-element").getAttribute("subdropdown");
    async function remove(dropdown) {
      dropdown.style.overflow = "hidden";
      dropdown.style.height = "0px";
      dropdown.style.opacity = 0;
      await sleep(150);
      dropdown.remove();
    }
    remove(dropdown);
  }
}
async function removeMainDropdown() {
  let dropdownFrame = dropdownFrameHolder.querySelector(".dropdown-frame");
  if (dropdownFrame == null) {
    return;
  }
  dropdownFrame.style.transition = "all .15s ease";
  await sleep(1);
  dropdownFrame.style.overflow = "hidden";
  dropdownFrame.style.height = "0px";
  dropdownFrame.style.opacity = 0;
  if (prevDropdownParent != null && prevDropdownParent.querySelector(".dropdown-arrow") != null) {
    prevDropdownParent.querySelector(".dropdown-arrow").style.transform = "rotate(0deg)";
  }
  prevDropdownParent = null;
}
async function renderDropdown(parent, items) {
  let dropdownFrame = dropdownFrameHolder.querySelector(".dropdown-frame");
  removeSubDropdowns(dropdownFrame.querySelector(".dropdown-element"));
  if (prevDropdownParent != null && prevDropdownParent.querySelector(".dropdown-arrow") != null) {
    prevDropdownParent.querySelector(".dropdown-arrow").style.transform = "rotate(0deg)";
  }
  if (parent == prevDropdownParent) {
    dropdownFrame.style.overflow = "hidden";
    dropdownFrame.style.height = "0px";
    dropdownFrame.style.opacity = 0;
    prevDropdownParent = null;
    return;
  }
  let wasHidden = prevDropdownParent == null && parent != prevPrevDropdownParent;
  prevDropdownParent = parent;
  prevPrevDropdownParent = parent;
  if (parent != null && parent.querySelector(".dropdown-arrow") != null) {
    parent.querySelector(".dropdown-arrow").style.transform = "rotate(-180deg)";
  }
  function createDropdownButtons(dropdownFrame, items) {
    if (dropdownFrame.querySelector(".dropdown-element") != null) {
      dropdownFrame.querySelector(".dropdown-element").remove();
    }
    let dropdownElement = createElement("dropdown-element", "div", dropdownFrame);
    for (let i = 0; i < items.length; i++) {
      function renderButton() {
        let item = items[i];
        if (item == "LINEBREAK") {
          createElement("dropdown-line-break", "div", dropdownElement);
        } else {
          let newButton = createElement("dropdown-button", "div", dropdownElement);
          if (item[3] != null) {
            createElement("dropdown-element-icon", "div", newButton, { content: "url(" + item[3] + ")" });
          }
          if (item[1] != null) {
            if (typeof item[1] == "string") {
              let dropdownText = createElement("dropdown-element-text", "div", newButton);
              dropdownText.id = "dropdown-" + item[0];
              dropdownText.textContent = item[0];
              if (window[item[1]] != null) {
                newButton.addEventListener("click", function() {
                  window[item[1]](item[2] || item[0]);
                });
              }
              newButton.addEventListener("mouseenter", async function() {
                removeSubDropdowns(newButton.parentElement);
              });
            } else {
              createElement("dropdown-element-text", "div", newButton, { "margin-right": "12px" }).textContent = item[0];
              createElement("dropdown-triangle", "div", newButton);
              let thisBDropdown = null;
              newButton.addEventListener("mouseenter", function() {
                let currentDropdown = findI(newButton.parentElement.parentElement.id + "sub");
                if (currentDropdown == null) {
                  currentDropdown = createElement("dropdown-frame", "div", dropdownFrameHolder, { position: "absolute" });
                  currentDropdown.id = newButton.parentElement.parentElement.id + "sub";
                } else {
                  removeSubDropdowns(currentDropdown.querySelector(".dropdown-element"));
                }
                thisBDropdown = currentDropdown;
                newButton.parentElement.setAttribute("subdropdown", currentDropdown.id);
                let dropdownElement = createDropdownButtons(currentDropdown, item[1]);
                let selfRect = newButton.getBoundingClientRect();
                currentDropdown.style.left = selfRect.left + newButton.clientWidth + "px";
                currentDropdown.style.top = selfRect.top - (newButton.clientHeight*2) + 6 + "px";
                currentDropdown.style.opacity = 1;
                currentDropdown.style.height = dropdownElement.clientHeight + 4 + "px";
              });
            }
          }
        }
      }
      renderButton();
    }
    return dropdownElement;
  }
  let dropdownElement = createDropdownButtons(dropdownFrame, items);
  dropdownElement.id = parent.querySelector(".dropdown-button-text").textContent;
  runDropAnim(dropdownFrame, dropdownElement, parent, wasHidden);
}

async function runDropAnim(dropdownFrame, dropdownElement, parent, wasHidden) {
  let rect = parent.getBoundingClientRect();
  if (wasHidden == true) {
    dropdownFrame.style.transition = "all 0s ease";
    dropdownFrame.style.left = rect.left + "px";
    dropdownFrame.style.top = rect.top + "px";
    await sleep(1);
    dropdownFrame.style.transition = "height .15s ease";
  } else {
    dropdownFrame.style.transition = "all .15s ease";
    dropdownFrame.style.top = rect.top + "px";
    dropdownFrame.style.left = rect.left + "px";
  }
  let selfRect = dropdownFrameHolder.getBoundingClientRect();
  dropdownFrame.style.overflow = "hidden";
  dropdownFrame.style.height = dropdownElement.clientHeight + 4 + "px";
  dropdownFrame.style.maxHeight = "calc(100vh - " + (selfRect.top + 18) + "px)";
  dropdownFrame.style.opacity = 1;
  await sleep(150);
  if (dropdownFrame.style.height == dropdownElement.clientHeight + 4 + "px") {
    dropdownFrame.style.overflow = "auto";
  }
}

function updateDropdown(section, text, newText, newFunction) {
  let data = dropdowns[section][0];
  function recursiveFunction(check) {
    for (let i = 0; i < check.length; i++) {
      let dropData = check[i];
      if (typeof dropData == "object") {
        if (dropData[0] == text) {
          data = dropData;
          return;
        }
        if (typeof dropData[1] == "object") {
          recursiveFunction(dropData[1]);
        }
      }
    }
  }
  recursiveFunction(dropdowns[section]);
  let dropdownB = findI("dropdown-" + data[0]);
  if (dropdownB != null) {
    dropdownB.id = "dropdown-" + newText;
    dropdownB.textContent = newText;
  }
  data[0] = newText;
  data[1] = newFunction;
}

let keepElement = null;
async function setKeepElem(elem) {
  await sleep(10);
  keepElement = elem;
}
document.addEventListener("click", function(e) {
  if (keepElement != null && e.target.closest("." + keepElement.className) == null) {
    keepElement.remove();
    keepElement = null;
  }
});

let epochOffset = 0;
function getEpoch() {
  return Date.now() + epochOffset;
}
async function sendRequest(method, path, body, noFileType) {
  let sendData = {
    method: method,
    headers: {
      cache: 'no-cache'
    }
  };
  if (noFileType != true) {
    sendData.headers["Content-Type"] = "text/plain";
  }
  if (body != null) {
    if (typeof body == "object" && body instanceof FormData == false) {
      body = JSON.stringify(body);
    }
    sendData.body = body;
  }
  let token = localStorage.getItem("token");
  if (token != null) {
    token = JSON.parse(token);
    if (token.expires > Math.floor(Date.now() / 1000)) {
      sendData.headers.auth = localStorage.getItem("userID") + ";" + token.token;
    }
  }
  let response = await fetch(serverURL + path, sendData);
  if (response.status == 401) {
    localStorage.removeItem("userID");
    localStorage.removeItem("token");
    location.reload();
  }
  let serverTimeMillisGMT = new Date(response.headers.get("Date")).getTime();
  let localMillisUTC = new Date().getTime();
  epochOffset = serverTimeMillisGMT - localMillisUTC;
  return [ response.status, await response.text() ];
}

function forceClickElement(textBox) {
  textBox.focus();
}

let finishedInit = false;

async function init() {
  if (localStorage.getItem("userID") != null && localStorage.getItem("token") != null) {
    let [ status, response ] = await sendRequest("GET", "account");
    if (status == 200) {
      account = JSON.parse(response);
      account.id = localStorage.getItem("userID");
    }
  }
  if (window.runInit != null) {
    runInit();
  }
  finishedInit = true;
}
init();