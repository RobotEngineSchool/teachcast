// Global Items Here:
let pageContainer;
let docHolder;
let stuckHolder;
let annotationsHolder;
let annotationSVG;
let renderItem;
let setSaveStatus;
let wirePages = {
  share: `
  <div class="modal" id="share-modal">
    <div class="modal-top">
      <div class="modal-title">Share and Present</div>
      <div class="modal-close">&#x2715</div>
    </div>
    <div class="modal-share-title">Share via Code</div>
    <div class="modal-share-desc">Invite members without an account with a 6 digit code. Members cannot edit by default.</div>
    <div class="modal-share-config-holder">
      <div class="modal-share-new-c">Generate</div>
      <div class="modal-share-code"></div>
      <img class="small-icon-button" id="view-share-code-fullscreen" hidden="true" src="./images/icons/fullscreen.svg" title="View Fullscreen"></img>
      <img class="small-icon-button" id="copy-share-code" hidden="true" src="./images/icons/copy.svg" title="Copy Code"></img>
    </div>
    <div class="modal-share-title">Share via Link</div>
    <!-- <div class="modal-share-desc">Share a link to easily allow members to join. Members can only view the document by default.</div> -->
    <div class="modal-share-desc">In the works...</div>
    <div class="modal-share-title">Invite via Email</div>
    <!-- <div class="modal-share-desc">Invite someone's account by typing their email. Members invited can only view the document by default but can be made long-term editors.</div> -->
    <div class="modal-share-desc">In the works...</div>
  </div>`,
  fullscreen: `
  <div class="modal" id="fullscreen-modal">
    <div class="modal-top">
      <div class="modal-title">Join the Session!</div>
      <div class="modal-close">&#x2715</div>
    </div>
    <div class="fullscreen-code"></div>
    <div class="fullscreen-horizontal-line"></div>
    <div class="sub-info-text">Join this session by going to <a class="hyperlink" href="https://teachcast.robotengine.repl.co/join.html" target="_blank">https://teachcast.robotengine.repl.co/join.html</a> and entering the above code.</div>
  </div>
  `,
  members: `
    <div class="modal" id="members-modal">
    </div>
  `
};
let session = {
  _id: "",
  pdfURL: "",
  annotations: {},
  permisions: ["view", "edit", "share", "download.new", "download.original"],
  currentTool: "select",
  lastSubTool: {},
  currentSetProp: {},
  lastSubProp: { annotate: { color: "#FFED46", colors: ["#FFED46", "#26FF67", "#FF0084"] }, text: { color: "#228EF2", colors: ["#228EF2", "#FF4454", "#000000"] }, draw: { color: "#DF84FF", colors: ["#DF84FF", "#72AAFF", "#53FF87"] }, shapes: { color: "#FF4454", colors: ["#FF4454", "#FFCD44", "#72AAFF"] } },
  currentPage: 1,
  lastPage: 1,
  mouse: { x: 0, y: 0, selections: [] },
  inserting: null,
  editing: false,
  zoom: 1,
  live: {
    members: {},
    lastSendMouse: { x: 0, y: 0, s: 0 }
  }
};
let defaultProfilePic = "../images/profilepic.svg";

function getScrollHeight() {
  return window.pageYOffset || (document.documentElement || document.body.parentNode || document.body).scrollTop;
}
function getScrollWidth() {
  return window.pageXOffset || (document.documentElement || document.body.parentNode || document.body).scrollLeft;
}
function scaleToDoc(x, y) {
  let { left, top } = docHolder.getBoundingClientRect();
  let scaleZoom = 1/session.zoom;
  return { x: Math.floor((x - (left*session.zoom))*scaleZoom), y: Math.floor((y - (top*session.zoom))*scaleZoom) };
}
function scaleToZoom(x, y) {
  let rect = docHolder.getBoundingClientRect();
  return { x: session.zoom * (x + rect.x + getScrollWidth()), y: session.zoom * (y + rect.top) + getScrollHeight() };
}
function openFullscreen() {
    if (body.requestFullscreen) {
      body.requestFullscreen();
    } else if (body.webkitRequestFullscreen) { // Safari
      body.webkitRequestFullscreen();
    } else if (body.msRequestFullscreen) { // IE11
      body.msRequestFullscreen();
    }
  }
function closeFullscreen() {
  if (document.exitFullscreen) {
    document.exitFullscreen();
  } else if (document.webkitExitFullscreen) { // Safari
    document.webkitExitFullscreen();
  } else if (document.msExitFullscreen) { // IE11
    document.msExitFullscreen();
  }
}
function syncAnnotations(annotations) {
  if (annotations == null) {
    return;
  }
  clearRenderedAnnotations();
  let keys = Object.keys(annotations);
  for (let i = 0; i < keys.length; i++) {
    let anno = annotations[keys[i]];
    let id = anno._id.replace(session.id, "");
    anno.id = id;
    delete anno._id;
    session.annotations[id] = anno;
    renderItem(anno);
  }
}
function clearRenderedAnnotations() {
  let annotations = document.getElementsByClassName("annotation-holder");
  for (let i = 0; i < annotations.length; i++) {
    annotations[i].remove();
    i -= 1;
  }
}
function syncMembers(addMembers) {
  for (let i = 0; i < addMembers.length; i++) {
    let newMember = addMembers[i];
    session.live.members[newMember._id] = newMember;
  }
}
function hash(text) {
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    let char = text.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return hash;
}
function createModal(content) {
  let modalHolder = createElement("modal-holder", "div", stuckHolder);
  modalHolder.innerHTML = content;
  modalHolder.addEventListener("click", function(e) {
    if ((e.target || e.changedTouches[0].target).closest(".modal") == null) {
      modalHolder.remove();
    }
  });
  let modalCloseB = modalHolder.querySelector(".modal-close");
  if (modalCloseB != null) {
    modalCloseB.addEventListener("click", function() {
      modalHolder.remove();
    });
  }
}
function closeModals() {
  let modals = document.getElementsByClassName("modal-holder");
  for (let i = 0; i < modals.length; i++) {
    modals[i].remove();
    i -= 1;
  }
}
function copyClipboardText(text) {
  navigator.clipboard.writeText(text).then(function(){},function(Error){console.error('Async: Could not copy text: ',Error);});
}
///////////////////

SimpleSocket.onclose = function() {
  let cursors = document.getElementsByClassName("live-cursor");
  for (let i = 0; i < cursors.length; i++) {
    cursors[i].remove();
    i -= 1;
  }
  let highlights = document.getElementsByClassName("live-selections");
  for (let i = 0; i < highlights.length; i++) {
    highlights[i].remove();
    i -= 1;
  }
  let selections = document.getElementsByClassName("live-selection-box");
  for (let i = 0; i < selections.length; i++) {
    selections[i].remove();
    i -= 1;
  }
  if (setSaveStatus != null) {
    setSaveStatus("reconnect");
  }
}

wireframes.edit = `<div class="stuck-holder"> <div class="top-bar"> <div class="product-logo"></div> <div class="document-name" title="Change File Name" contenteditable></div> <div class="file-button" onclick='renderDropdown(this, dropdowns.file)'> <div class="dropdown-button-text">File</div> <div class="dropdown-arrow"></div> </div> <div class="file-saved-text" title=""></div> <div class="view-members-button" onclick='displayMembersMenu(this)'> <div class="dropdown-button-text">Members</div> <div class="view-members-amount"></div> <div class="dropdown-arrow"></div> </div> <div class="share-code-display"></div> <div class="share-button">Share</div> <div class="options-button" onclick='renderDropdown(this, dropdowns.zoom)'> <div class="dropdown-button-text" id="zoom-level-tx">100%</div> <div class="dropdown-arrow"></div> </div> <img class="account-profile-image"></img> </div> <div class="toolbar"> <div class="toolbar-main"> <div class="toolbar-button" id="select" style="background-color: #228EF2"> <img class="toolbar-button-img" src="./images/toolbar/cursor.svg"></img> <div class="toolbar-button-title">Select</div> <div class="toolbar-dropdown-triangle" style="width: 12px"></div> </div> <div class="toolbar-button" id="annotate"> <img class="toolbar-button-img" src="./images/toolbar/highlighter.svg"></img> <div class="toolbar-button-title">Annotate</div> </div> <div class="toolbar-button" id="text"> <img class="toolbar-button-img" src="./images/toolbar/text.svg"></img> <div class="toolbar-button-title">Text</div> </div> <div class="toolbar-button" id="draw"> <img class="toolbar-button-img" src="./images/toolbar/draw.svg"></img> <div class="toolbar-button-title">Draw</div> </div> <div class="toolbar-button" id="shapes"> <img class="toolbar-button-img" src="./images/toolbar/shapes.svg"></img> <div class="toolbar-button-title">Shapes</div> </div> <div class="toolbar-button" id="note"> <img class="toolbar-button-img" src="./images/toolbar/notes.svg"></img> <div class="toolbar-button-title">Note</div> </div> <div class="toolbar-button" id="media"> <img class="toolbar-button-img" src="./images/toolbar/media.svg"></img> <div class="toolbar-button-title">Media</div> </div> <div class="drag-toolbar"></div> </div> </div> <div class="bottom-bar"> <div class="live-session-tab"><div class="live-circle"></div> Join Live Session <span class="view-members-amount" id="live-session-count"></span></div> <div class="page-number"><b class="page-number-text">Page 1</b> /<span class="page-number-total">1</span></div> </div> </div> <div class="center-holder" id="page-container"> <div class="document-holder"> <div class="dropdown-element"></div> <div class="annotations-holder"> <svg class="annotation-svg-holder"></svg> </div> </div> </div> <div class="static-holder"></div>`;

mainLoadActions.main = async function actionInitMain(docID, knownURL, knownData) {
  knownData = knownData || {};
  pageContainer = findI("page-container");
  annotationsHolder = findC("annotations-holder");
  annotationSVG = findC("annotation-svg-holder");
  docHolder = findC("document-holder");
  stuckHolder = findC("stuck-holder");

  session.id = docID;
  
  session.annotations = {};
  let docData = {};
  async function reconnectSync() {
    let method = "GET";
    let path = "load?doc=" + docID + "&ss=" + SimpleSocket.SecureID;
    let body = null;
    if (knownData.code != null) {
      method = "POST";
      path = "load?ss=" + SimpleSocket.SecureID;
      body = { code: knownData.code, name: knownData.name };
    }
    session.live.members = {};
    let [ status, response ] = await sendRequest(method, path, body);
    if (status == 200) {
      docData = JSON.parse(response);
      session.id = docData.document._id;
      session.pdfURL = assetURL + docData.document.url;
      session.name = docData.document.name || "Untitled Document";
      session.shareCode = docData.document.code;
      syncMembers(docData.members || [])
      connectRun();
    }
  }
  if (SimpleSocket.SecureID == null) {
    await new Promise(async function(resolve, reject) {
      SimpleSocket.onopen = function() {
        resolve();
      }
    });
  }
  if (knownURL == null) {
    let method = "GET";
    let path = "load?doc=" + docID + "&ss=" + SimpleSocket.SecureID;
    let body = null;
    if (knownData.code != null) {
      method = "POST";
      path = "load?ss=" + SimpleSocket.SecureID;
      body = { code: knownData.code, name: knownData.name };
    }
    session.live.members = {};
    let [ status, response ] = await sendRequest(method, path, body);
    if (status == 200) {
      docData = JSON.parse(response);
      session.id = docData.document._id;
      session.pdfURL = assetURL + docData.document.url;
      session.name = docData.document.name || "Untitled Document";
      session.shareCode = docData.document.code;
      syncMembers(docData.members || [])
    }
  } else {
    // Is a new document:
    session.pdfURL = knownURL;
    session.name = knownData.name || "Untitled Document";
  }
  SimpleSocket.onopen = function() {
    reconnectSync();
    setSaveStatus("connect");
  }

  let docName = findC("document-name");
  
  async function connectRun() {
    closeModals();
    
    docName.textContent = session.name;
    
    let codeOnBar = findC("share-code-display");
    if (session.shareCode != null) {
      codeOnBar.textContent = session.shareCode || "";
      codeOnBar.style.display = "block";
    } else {
      codeOnBar.style.display = "none";
    }

    if (knownData.code == null) {
      let profilePic = findC("account-profile-image");
      profilePic.src = account.image;
      profilePic.addEventListener("click", function() {
        let dispElem = createElement("profile-info-holder", "div", dropdownFrameHolder);
        dispElem.innerHTML = wireframes.userinfo.replace(/IMAGE_URL/g, account.image).replace(/USERNAME/g, account.user).replace(/EMAIL/g, account.email);
        setKeepElem(dispElem);
        findI("profile-info-logout").addEventListener("click", async function() {
          dispElem.remove();
          let [ status, response ] = await sendRequest("HEAD", "logout");
          if (status == 200) {
            localStorage.removeItem("userID");
            localStorage.removeItem("token");
            location.reload();
          }
        });
      });
    } else {
      findC("share-button").style.display = "none";
    }
    
    syncAnnotations(docData.annotations);
  }
  
  findC("product-logo").addEventListener("click", function() {
    pages.home();
  });
  findC("share-button").addEventListener("click", function() {
    removeMainDropdown();
    let modalHolder = createModal(wirePages.share);
    let createCodeB = findC("modal-share-new-c");
    let shareCodeTx = findC("modal-share-code");
    if (session.shareCode != null) {
      shareCodeTx.textContent = session.shareCode;
      createCodeB.textContent = "Remove";
      createCodeB.style.backgroundColor = "var(--errorRed)";
      findI("view-share-code-fullscreen").hidden = false;
      findI("copy-share-code").hidden = false;
    }
    createCodeB.addEventListener("click", async function() {
      createCodeB.style.display = "none";
      shareCodeTx.textContent = "Loading...";
      findI("view-share-code-fullscreen").hidden = true;
      findI("copy-share-code").hidden = true;
      let [ status, response ] = await sendRequest("PUT", "code?doc=" + docID);
      if (status == 200) {
        if (response != "removed") {
          session.shareCode = response;
          shareCodeTx.textContent = response;
          createCodeB.textContent = "Remove";
          createCodeB.style.backgroundColor = "var(--errorRed)";
          createCodeB.style.display = "flex";
          findI("view-share-code-fullscreen").hidden = false;
          findI("copy-share-code").hidden = false;
        } else {
          session.shareCode = null;
          createCodeB.textContent = "Generate";
          createCodeB.style.backgroundColor = "var(--brightBlue)";
          createCodeB.style.display = "flex";
          shareCodeTx.textContent = "";
        }
      } else {
        shareCodeTx.textContent = "";
        createCodeB.textContent = "Generate";
        createCodeB.style.backgroundColor = "var(--brightBlue)";
        createCodeB.style.display = "flex";
      }
    });
    findI("view-share-code-fullscreen").addEventListener("click", function() {
      modalCodeFullscreenHolder = createModal(wirePages.fullscreen);
      findC("fullscreen-code").textContent = session.shareCode;
    });
    findI("copy-share-code").addEventListener("click", function() {
      copyClipboardText("Join a session by going to https://teachcast.robotengine.repl.co/join.html and entering the code: " + session.shareCode);
    });
  });

  let prevName = session.name;
  docName.addEventListener("focusout", async function() {
    docName.textContent = docName.textContent.substring(0, 40);
    let [ status ] = await sendRequest("PUT", "name?doc=" + docID, docName.textContent);
    if (status != 200) {
      docName.textContent = prevName;
    }
  });
  
  let statusTx = findC("file-saved-text");
  setSaveStatus = function setSaveStatus(status) {
    if (status == "saved") {
      statusTx.textContent = "Saved Edits";
    } else if (status == "saving") {
      statusTx.textContent = "Saving...";
    } else if (status == "reconnect") {
      statusTx.textContent = "Reconnecting...";
    } else if (status == "connect") {
      statusTx.textContent = "Connected";
    }
  }

  tempListen(document, "fullscreenchange", function() {
    if (document.fullscreenElement != null) {
      updateDropdown("zoom", "Fullscreen", "Exit Fullscreen", "closeFullscreen");
    } else {
      updateDropdown("zoom", "Exit Fullscreen", "Fullscreen", "openFullscreen");
    }
  });
  
  dragElement(findC("drag-toolbar"));
  function dragElement(dragIcon) {
    let element = dragIcon.parentElement.parentElement;
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    dragIcon.addEventListener("mousedown", dragMouseDown);
    dragIcon.addEventListener("touchstart", dragMouseDown);
    
    tempListen(window, "resize", function(e) {
      let rect = element.getBoundingClientRect();
      let setX = element.offsetLeft;
      let setY = element.offsetTop;
      if (rect.left <= 8) {
        setX = 8;
      }
      if (window.innerWidth - rect.right <= 8) {
        setX = window.innerWidth - element.clientWidth - 8;
      }
      if (rect.top <= 58) {
        setY = element.clientHeight/2 + 58;
      }
      if (window.innerHeight - rect.bottom <= 48) {
        setY = window.innerHeight - element.clientHeight/2 - 48;
      }
      element.style.left = setX + "px";
      element.style.top = setY + "px";
    });
    
    function dragMouseDown(e) {
      e = e || window.event;
      e.preventDefault();
      pos3 = e.clientX || e.changedTouches[0].clientX;
      pos4 = e.clientY || e.changedTouches[0].clientY;
      tempListen(document, "mouseup", closeDragElement);
      tempListen(document, "mousemove", elementDrag);
      tempListen(document, "touchend", closeDragElement);
      tempListen(document, "touchmove", elementDrag);
    }
  
    function elementDrag(e) {
      e = e || window.event;
      if (e.clientX == null && e.changedTouches == null) {
        return;
      }
      if (e.changedTouches != null) {
        e.clientX = e.changedTouches[0].clientX;
        e.clientY = e.changedTouches[0].clientY;
      }
      e.preventDefault();
      let rect = element.getBoundingClientRect();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      let setX = (element.offsetLeft - pos1);
      let setY = (element.offsetTop - pos2);
      if (pos1 > 0 && rect.left <= 8) {
        setX = 8;
      }
      if (pos1 < 0 && window.innerWidth - rect.right <= 8) {
        setX = window.innerWidth - element.clientWidth - 8;
      }
      if (pos2 > 0 && rect.top <= 58) {
        setY = element.clientHeight/2 + 58;
      }
      if (pos2 < 0 && window.innerHeight - rect.bottom <= 48) {
        setY = window.innerHeight - element.clientHeight/2 - 48;
      }
      pos3 = e.clientX;
      pos4 = e.clientY;
      element.style.left = setX + "px";
      element.style.top = setY + "px";
      if (window.closeWideHolder != null) {
        closeWideHolder();
      }
    }
  
    function closeDragElement() {
      document.removeEventListener("mouseup", closeDragElement);
      document.removeEventListener("mousemove", elementDrag);
      document.removeEventListener("touchend", closeDragElement);
      document.removeEventListener("touchmove", elementDrag);
    }
  }        
  
  pdfjsLib.GlobalWorkerOptions.workerSrc = "../pdfjs/build/pdf.worker.js";
  
  function updateRenderedPages(minPage, maxPage) {
    minPage = Math.max(minPage, 1);
    maxPage = Math.min(maxPage, session.totalPages);
    for (let i = minPage; i < maxPage+1; i++) {
      if (findI("rendered-page-" + i) == null) {
        session.pdf.getPage(i).then(async function(page) {
          let pageHolder = findI("document-page-" + (page._pageIndex+1));
          if (pageHolder == null || pageHolder.querySelector(".rendered-page") != null) {
            return;
          }
          
          let viewport = page.getViewport({ scale: docHolder.clientWidth / page.getViewport({ scale: 1 }).width });
          
          let canvas = createElement("rendered-page", "canvas", pageHolder);
          canvas.id = "rendered-page-" + i;
          let context = canvas.getContext('2d');
          
          canvas.width = viewport.width;
          canvas.height = viewport.height;
          canvas.style.width = viewport.width + "px";
          canvas.style.height = viewport.height + "px";
          
          let renderContext = {
            canvasContext: context,
            viewport: viewport
          };
          page.render(renderContext);
        });
      }
    }
    
    let preRenderedPages = document.getElementsByClassName("rendered-page");
    for (let r = 0; r < preRenderedPages.length; r++) {
      let canvas = preRenderedPages[r];
      let canvasNumber = parseInt(canvas.id.replace(/rendered-page-/g, ""));
      if (canvasNumber < minPage || canvasNumber > maxPage) {
        canvas.remove();
      }
    }
  }
  
  let loadingTask = pdfjsLib.getDocument(session.pdfURL); //pdftests/2017CSFRQ.pdf
  loadingTask.promise.then(function(pdf) {
    session.pdf = pdf;
    session.totalPages = pdf._pdfInfo.numPages;
    findC("page-number-total").textContent = pdf._pdfInfo.numPages;
    for (let i = 1; i < pdf._pdfInfo.numPages+1; i++) {
      pdf.getPage(i).then(async function(page) {
        let viewport = page.getViewport({ scale: docHolder.clientWidth / page.getViewport({ scale: 1 }).width });
        
        let pageHolder = createElement("page-holder", "div", docHolder);
        pageHolder.id = "document-page-" + i;
        
        pageHolder.style.width = viewport.width + "px";
        pageHolder.style.height = viewport.height + "px";
        
        /*
        let canvas = createElement("rendered-page", "canvas", pageHolder);
        canvas.id = "rendered-page-" + i;
        let context = canvas.getContext('2d');
        
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        canvas.style.width = viewport.width + "px";
        canvas.style.height = viewport.height + "px";
        
        let renderContext = {
          canvasContext: context,
          viewport: viewport
        };
        page.render(renderContext);
        */
  
        if (i < pdf._pdfInfo.numPages) {
          createElement("dashed-seperator", "div", docHolder)
        }
        updateRenderedPages(1, 4);
        
        checkForText(page, pageHolder, viewport);
        function checkForText(page, pageHolder, viewport) {
          page.getTextContent({ normalizeWhitespace: true }).then(async function(textContent) {
            if (textContent.items.length > 0) {
              let textHolder = createElement("page-text-holder", "div", pageHolder);
              pdfjsLib.renderTextLayer({
                enhanceTextSelection: true,
                textContent: textContent,
                container: textHolder,
                viewport: viewport,
                textDivs: []
              });
            }
          });
        }
      });
    }
  });
  
  window.setZoomLevel = function setZoomLevel(zoom) {
    if (zoom > 2.5) {
      zoom = 2.5;
    } else if (zoom < 0.15) {
      zoom = 0.2;
    }
    session.zoom = zoom;
    docHolder.style.zoom = zoom;
    findI("zoom-level-tx").textContent = Math.round(zoom*100) + "%";
  }
  window.addZoomLevel = function addZoomLevel(add) {
    setZoomLevel(session.zoom + add);
  }
  function scrollMouseWheel(e) {
    if (e.ctrlKey || e.metaKey) {
      if (e.wheelDelta > 0) {
        addZoomLevel(0.1);
      } else if (e.wheelDelta < 0) {
        addZoomLevel(-0.1);
      }
      e.preventDefault();
    }
  }
  tempListen(window, "DOMMouseScroll", scrollMouseWheel, { passive: false });
  tempListen(window, "mousewheel", scrollMouseWheel, { passive: false });
  
  let currentPageCounter = findC("page-number-text");
  tempListen(window, "scroll", function() {
    if (session.inserting != null) {
      openEditBar(getXYPos(session.inserting));
    }
    
    let pages = docHolder.children;
    let scrollHeight = window.innerHeight/2;// + getScrollHeight();
    let closestPos = docHolder.clientHeight;
    let currentPage = 1;
    let pageAdd = 0;
    for (let i = 0; i < pages.length; i++) {
      let page = pages[i];
      if (page.className == "page-holder") {
        pageAdd += 1;
        let rect = pages[i].getBoundingClientRect();
        let abscomp = Math.abs((rect.top + rect.height/2) - scrollHeight);
        //console.log(i, abscomp, closestPos)
        if (abscomp < closestPos) {
          closestPos = abscomp;
          currentPage = pageAdd;
        }
      }
    }
    session.currentPage = currentPage;
    currentPageCounter.textContent = "Page " + currentPage;
    if (currentPage != session.lastPage) {
      session.lastPage = currentPage;
      updateRenderedPages(currentPage-3, currentPage+3);
    }
  });
  
  function createSVG(setClass, type, parent) {
    let newSVG = document.createElementNS("http://www.w3.org/2000/svg", type);
    newSVG.setAttribute("class", setClass);
    parent.appendChild(newSVG);
    return newSVG;
  }
  
  renderItem = function renderItem(annotation, customSet) {
    try {
    if (typeof annotation == "string") {
      annotation = session.annotations[annotation];
    }
    if (annotation.local == null) {
      annotation.local = {};
    }
    let local = annotation.local;
    let setTransfrom = "";
    let annObj = null;
    switch (annotation.f) {
      case "draw":
        if (local.elem == null) {
          local.elem = createSVG("annotation-holder", "g", annotationSVG);
          local.elem.id = "annotation_" + annotation.id;
          local.elem.setAttribute("pointer-events", "visiblePainted");
          let svgPath = createSVG("annotation", "polyline", local.elem);
          svgPath.setAttribute("fill", "none");
          svgPath.setAttribute("stroke-linecap", "round");
          svgPath.setAttribute("stroke-linejoin", "round");
        }
        let setPoints = "";
        if (annotation.p.length == 2) {
          setPoints = annotation.p[0] + "," + annotation.p[1] + " " + (annotation.p[0] + 0.1) + "," + (annotation.p[1] + 0.1);
        } else {
          for (let i = 0; i < annotation.p.length; i += 2) {
            setPoints += annotation.p[i] + "," + annotation.p[i+1] + " ";
          }
        }
        let path = local.elem.querySelector(".annotation");
        path.setAttribute("points", setPoints);
        path.setAttribute("stroke", annotation.c);
        path.setAttribute("stroke-width", annotation.t);
        path.setAttribute("opacity", annotation.o);
        if (annotation.bo == "dash") {
          path.setAttribute("stroke-dasharray", annotation.t*2);
        } else if (path.hasAttribute("stroke-dasharray") == true) {
          path.removeAttribute("stroke-dasharray");
        }
        
        setTransfrom = "translate(" + (annotation.x || 0) + "," + (annotation.y || 0) + ")";
        if (annotation.w != null || annotation.h != null) {
          let bBox = local.elem.getBBox();
          setTransfrom += " scale(" + (annotation.w / bBox.width) + "," + (annotation.h / bBox.height) + ")";
        }
        local.elem.setAttribute("transform", setTransfrom);
        break;
      case "erase":
        if (session.annotations[annotation.r] != null) {
          delete session.annotations[annotation.r];
          let elementAnnotation = findI("annotation_" + annotation.r);
          if (elementAnnotation != null) {
            elementAnnotation.remove();
          }
        }
        break;
      case "annotate":
        if (local.elem != null) {
          local.elem.remove();
        }
        local.elem = createSVG("annotation-holder", "g", annotationSVG);
        local.elem.id = "annotation_" + annotation.id;
        local.elem.setAttribute("pointer-events", "visiblePainted");
        for (let i = 0; i < annotation.p.length; i++) {
          let newHighlight = createSVG("annotation", "rect", local.elem);
          newHighlight.setAttribute("width", annotation.p[i].w);
          newHighlight.setAttribute("height", annotation.p[i].h);
          newHighlight.setAttribute("x", annotation.p[i].x);
          newHighlight.setAttribute("y", annotation.p[i].y);
          newHighlight.setAttribute("fill", annotation.c);
          newHighlight.setAttribute("opacity", annotation.o);
        }
        setTransfrom = "translate(" + annotation.x + "," + annotation.y + ")";
        if (annotation.w != null || annotation.h != null) {
          let bBox = local.elem.getBBox();
          setTransfrom += " scale(" + (annotation.w / bBox.width) + "," + (annotation.h / bBox.height) + ")";
        }
        local.elem.setAttribute("transform", setTransfrom);
        break;
      case "text":
        if (local.elem == null) {
          local.elem = createElement("annotation-holder", "div", annotationsHolder);
          local.elem.id = "annotation_" + annotation.id;
          let textBox = createElement("annotation", "div", local.elem);
          textBox.textContent = "Text Box Here (Soon)";
          textBox.setAttribute("contenteditable", "true");
          textBox.style.pointerEvents = "all";
        }
        annObj = local.elem.querySelector(".annotation");
        local.elem.style.height = annotation.h + "px";
        annObj.style.fontSize = annotation.h + "px";
        local.elem.style.left = annotation.x + "px";
        local.elem.style.top = annotation.y + "px";
        local.elem.style.color = annotation.c;
        break;
      case "shape":
        if (customSet != null) {
          annotation = { ...annotation, ...customSet };
        }
        if (local.elem == null) {
          let shapeHolder = annotationSVG;
          let type = "g";
          if (annotation.sol != null) {
            type = "svg";
            shapeHolder = annotation.sol;
          }
          local.elem = createSVG("annotation-holder", type, shapeHolder);
          local.elem.id = "annotation_" + annotation.id;
          local.elem.setAttribute("pointer-events", "visiblePainted");
          if (customSet != null) {
            local.elem.id = "locked-placing-element";
          }
        }
        if (local.elem != null) {
          annObj = local.elem.querySelector(".annotation");
        }
        if (annObj == null || annObj.nodeName != annotation.s) {
          if (annObj != null) {
            annObj.remove();
          }
          annObj = createSVG("annotation", annotation.s, local.elem, { "position": "absolute", "background-color": annotation.c, "opacity": annotation.o });
        }
        let addTransform = "";
        switch (annotation.s) {
          case "rect":
            if (annotation.w < 0 && annotation.h < 0) {
              addTransform += " scale(-1,-1)";
            } else if (annotation.w < 0) {
              addTransform += " scale(-1,1)";
            } else if (annotation.h < 0) {
              addTransform += " scale(1,-1)";
            }
            annObj.setAttribute("width", Math.max(1, Math.abs(annotation.w)));
            annObj.setAttribute("height", Math.max(1, Math.abs(annotation.h)));
            //annObj.setAttribute("x", annoX);
            //annObj.setAttribute("y", annotation.y);
            annObj.setAttribute("rx", "5");
            annObj.setAttribute("ry", "5");
            break;
          case "ellipse":
            if (annotation.w < 0 && annotation.h < 0) {
              addTransform += " scale(-1,-1)";
            } else if (annotation.w < 0) {
              addTransform += " scale(-1,1)";
            } else if (annotation.h < 0) {
              addTransform += " scale(1,-1)";
            }
            annObj.setAttribute("rx", Math.max(1, Math.abs(annotation.w)) / 2);
            annObj.setAttribute("ry", Math.max(1, Math.abs(annotation.h)) / 2);
            annObj.setAttribute("cx", Math.max(1, Math.abs(annotation.w)) / 2);
            annObj.setAttribute("cy", Math.max(1, Math.abs(annotation.h)) / 2);
            break;
          case "polygon":
            annObj.setAttribute("points", (annotation.w / 2) + ",0 0," + annotation.h + " " +annotation.w + "," + annotation.h);
            annObj.setAttribute("stroke-linejoin", "round");
            break;
          case "line":
            annObj.setAttribute("x1", 0);
            annObj.setAttribute("y1", 0);
            annObj.setAttribute("x2", annotation.w);
            annObj.setAttribute("y2", annotation.h);
            annObj.setAttribute("stroke-linecap", "round");
        }
        annObj.setAttribute("opacity", annotation.o || 0.6);
        if (annotation.t != null && annotation.bo != "none") {
          annObj.setAttribute("stroke-width", annotation.t);
        } else if (annObj.hasAttribute("stroke-width") == true) {
          annObj.removeAttribute("stroke-width");
        }
        let strokeColor = annotation.c;
        if (annotation.fi != null) {
          annObj.setAttribute("fill", annotation.c);
          if (annotation.s != "line") {
            strokeColor = darkenHex(annotation.c, -50);
          }
        } else {
          annObj.setAttribute("fill", "none");
        }
        if (annotation.bo != "none") {
          if (annotation.bo == "dash") {
            annObj.setAttribute("stroke-dasharray", annotation.t*2);
          } else if (annObj.hasAttribute("stroke-dasharray") == true) {
            annObj.removeAttribute("stroke-dasharray");
          }
          annObj.setAttribute("stroke", strokeColor);
        } else if (annObj.hasAttribute("stroke") == true) {
          annObj.removeAttribute("stroke");
        }
        if (annotation.sol != null) {
          local.elem.style.left = (annotation.w/-2) - (annotation.t/2) + "px";
          local.elem.style.top = (annotation.h/-2) - (annotation.t/2) + "px";
          annObj.setAttribute("transform", "translate(" + (annotation.t/2) + ", " + (annotation.t/2) + ")");
        } else {
          local.elem.setAttribute("transform", "translate(" + (annotation.x || 0) + ", " + (annotation.y || 0) + ")" + addTransform);
        }
        break;
    }
    let selectionBoxs = document.querySelectorAll('[annoid="' + annotation.id + '"]');
    for (let i = 0; i < selectionBoxs.length; i++) {
      let elem = selectionBoxs[i];
      let borderW = 4;
      if (elem.className == "live-selection-box") {
        borderW = 2;
      }
      let { xPos, yPos, setWidth, setHeight } = getXYPos(annotation, borderW);
      elem.style.width = setWidth + "px";
      elem.style.height = setHeight + "px";
      elem.style.left = xPos + "px";
      elem.style.top = yPos + "px";
    }
    if (session.inserting != null && annotation != null && session.inserting.id == annotation.id && local.elem != null && local.elem.id != "locked-placing-element") {
      openEditBar(getXYPos(annotation));
    }
    } catch(err) { console.log("RENDER ERROR:", err); }
  }
  
  function darkenHex(color, amount) {
    return '#' + color.replace(/^#/, '').replace(/../g, color => ('0'+Math.min(255, Math.max(0, parseInt(color, 16) + amount)).toString(16)).substr(-2));
  }

  connectRun();
  
  mainLoadActions.live();
  mainLoadActions.toolbar();
}

async function createLiveMemberTile(data, holder) {
  let newTile = createElement("member-tile", "div", holder);
  newTile.id = "member-tile-" + data._id;
  createElement("member-tile-profile-pic", "img", newTile, { "border-color": data.c }).src = data.i || defaultProfilePic;
  createElement("member-tile-name", "div", newTile).textContent = data.u;
  holder.parentElement.style.height = holder.clientHeight + 4 + "px";
}

async function displayMembersMenu(parent) {
  let dropdownFrame = dropdownFrameHolder.querySelector(".dropdown-frame");
  if (prevDropdownParent != null && prevDropdownParent.querySelector(".dropdown-arrow") != null) {
    prevDropdownParent.querySelector(".dropdown-arrow").style.transform = "rotate(0deg)";
  }
  if (parent == prevDropdownParent) {
    dropdownFrame.style.overflow = "hidden";
    dropdownFrame.style.height = "0px";
    dropdownFrame.style.opacity = 0;
    prevDropdownParent = null;
    return;
  }
  let wasHidden = prevDropdownParent == null && parent != prevPrevDropdownParent;
  prevDropdownParent = parent;
  prevPrevDropdownParent = parent;
  if (parent != null && parent.querySelector(".dropdown-arrow") != null) {
    parent.querySelector(".dropdown-arrow").style.transform = "rotate(-180deg)";
  }
  //let dropdownFrame = findC("dropdown-frame-holder");
  if (dropdownFrame.querySelector(".dropdown-element") != null) {
    dropdownFrame.querySelector(".dropdown-element").remove();
  }
  let membersMenu = createElement("dropdown-element", "div", dropdownFrame);
  membersMenu.id = "dropdown-members-list";
  let keys = Object.keys(session.live.members);
  for (let i = 0; i < keys.length; i++) {
    createLiveMemberTile(session.live.members[keys[i]], membersMenu);
  }
  await runDropAnim(dropdownFrame, membersMenu, parent, wasHidden);
  dropdownFrame.style.transition = "all 0s ease";
}